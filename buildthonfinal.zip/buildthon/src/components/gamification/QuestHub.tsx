import React, { useState } from 'react';
import {
  Award,
  CheckCircle2,
  ChevronRight,
  Compass,
  Flame,
  GraduationCap,
  HeartHandshake,
  HelpCircle,
  Lock,
  Sparkles,
  Star,
  TrendingUp,
  Trophy,
  Users2,
  Zap,
} from 'lucide-react';
import { DailyQuest, LeaderboardEntry, UserProfile } from '../../types';
import {
  ALL_BADGES,
  LEVELS,
  calculateImpactScore,
  getXPProgress,
} from '../../services/gamification';

interface QuestHubProps {
  currentUser: UserProfile;
  dailyQuests: DailyQuest[];
  onClaimQuest: (questId: string) => void;
  leaderboard: LeaderboardEntry[];
  onNavigate: (page: string) => void;
}

export const QuestHub: React.FC<QuestHubProps> = ({
  currentUser,
  dailyQuests,
  onClaimQuest,
  leaderboard,
  onNavigate,
}) => {
  const [leaderboardTab, setLeaderboardTab] = useState<'all' | 'learner' | 'tutor'>('all');
  const [selectedBadgeId, setSelectedBadgeId] = useState<string | null>(null);

  const xpProg = getXPProgress(currentUser.xp);

  // Filter leaderboard
  const filteredLeaderboard = leaderboard.filter((item) => {
    if (leaderboardTab === 'all') return true;
    return item.role === leaderboardTab;
  });

  // Calculate detailed impact breakdown
  const impactDetails = calculateImpactScore({
    sessionsCompleted: Math.max(1, Math.round(currentUser.impactScore / 40)),
    uniqueStudentsHelped: currentUser.role === 'tutor' ? 4 : 1,
    distinctSubjects: 3,
    positiveReviewsCount: currentUser.role === 'tutor' ? 8 : 1,
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="relative overflow-hidden p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white shadow-xl shadow-purple-950/20">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 rounded-full bg-violet-500/20 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-purple-200 text-xs font-bold">
              <Trophy className="w-3.5 h-3.5 text-amber-300" />
              <span>BrainBridge Quest &bull; Verified Campus Learning</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Gamified Leveling &amp; Achievements
            </h1>
            <p className="text-sm text-purple-200 max-w-xl leading-relaxed">
              Every completed tutoring session, constructive review, and study milestone contributes to your verified academic reputation.
            </p>
          </div>

          {/* Current Level Pill */}
          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center sm:text-right shrink-0">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-purple-200 block">
              Current Rank
            </span>
            <span className="text-xl sm:text-2xl font-black text-amber-300">
              Level {currentUser.level}: {currentUser.levelTitle}
            </span>
            <p className="text-xs text-purple-200 mt-0.5">
              {currentUser.xp} Lifetime XP
            </p>
          </div>
        </div>
      </div>

      {/* Level Tier Progression Bar */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-extrabold text-base text-slate-900">
              Rank Pathway &amp; Level Milestones
            </h3>
            <p className="text-xs text-slate-500">
              Progress to {xpProg.nextLevelTarget} XP to unlock the next title tier
            </p>
          </div>
          <span className="text-xs font-black text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200 self-start sm:self-auto">
            {xpProg.progressPercent}% to next rank
          </span>
        </div>

        {/* Big Progress Bar */}
        <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-600 via-violet-600 to-amber-500 rounded-full transition-all duration-700"
            style={{ width: `${xpProg.progressPercent}%` }}
          />
        </div>

        {/* Level Steps */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-3">
          {LEVELS.map((lvl) => {
            const isCurrent = currentUser.level === lvl.level;
            const isUnlocked = currentUser.level >= lvl.level;
            return (
              <div
                key={lvl.level}
                className={`p-3 rounded-2xl border text-center transition ${
                  isCurrent
                    ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-600/30'
                    : isUnlocked
                    ? 'border-slate-200 bg-slate-50'
                    : 'border-slate-200/60 bg-slate-50/40 opacity-60'
                }`}
              >
                <div
                  className={`w-7 h-7 mx-auto rounded-full flex items-center justify-center text-xs font-bold mb-1.5 ${
                    isCurrent
                      ? 'bg-indigo-600 text-white'
                      : isUnlocked
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-200 text-slate-400'
                  }`}
                >
                  {isUnlocked ? lvl.level : <Lock className="w-3.5 h-3.5" />}
                </div>
                <h5 className="font-bold text-xs text-slate-900">{lvl.title}</h5>
                <p className="text-[10px] text-slate-400">{lvl.minXP}+ XP</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Quests Section */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Daily Quests &bull; {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
            </h3>
            <p className="text-xs text-slate-500">
              Quests refresh every calendar day based on real qualifying learning actions.
            </p>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold">
            <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
            <span>{currentUser.streakDays} Day Streak Active</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {dailyQuests.map((quest) => (
            <div
              key={quest.id}
              className={`p-5 rounded-2xl border transition flex flex-col justify-between ${
                quest.isClaimed
                  ? 'bg-slate-50/80 border-slate-200 opacity-60'
                  : quest.isCompleted
                  ? 'bg-amber-50/60 border-amber-300 ring-2 ring-amber-400/20'
                  : 'bg-white border-slate-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                    +{quest.xpReward} XP
                  </span>
                  {quest.isClaimed && (
                    <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Claimed
                    </span>
                  )}
                </div>

                <h4 className="font-bold text-sm text-slate-900 mb-1">{quest.title}</h4>
                <p className="text-xs text-slate-500 leading-relaxed mb-3">
                  {quest.description}
                </p>
              </div>

              <div>
                {/* Progress bar */}
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                  <span>Progress</span>
                  <span className="font-bold">
                    {quest.currentCount} / {quest.targetCount}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mb-3">
                  <div
                    className="bg-indigo-600 h-full rounded-full"
                    style={{
                      width: `${Math.min(100, (quest.currentCount / quest.targetCount) * 100)}%`,
                    }}
                  />
                </div>

                {quest.isClaimed ? (
                  <button
                    disabled
                    className="w-full py-2 bg-slate-100 text-slate-400 font-bold text-xs rounded-xl"
                  >
                    Reward Claimed
                  </button>
                ) : quest.isCompleted ? (
                  <button
                    onClick={() => onClaimQuest(quest.id)}
                    className="w-full py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-amber-500/20 transition active:scale-95 animate-pulse"
                  >
                    Claim +{quest.xpReward} XP!
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      if (quest.questType === 'find_tutor') onNavigate('tutors');
                      if (quest.questType === 'send_goal') onNavigate('tutors');
                      if (quest.questType === 'complete_session') onNavigate('sessions');
                      if (quest.questType === 'study_circle') onNavigate('circles');
                    }}
                    className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold text-xs rounded-xl border border-slate-200 transition"
                  >
                    Start Quest &rarr;
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievement Badges Showcase */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-600" />
              Achievement Badges
            </h3>
            <p className="text-xs text-slate-500">
              Unlocked solely upon satisfying actual verifiable requirements.
            </p>
          </div>
          <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-200">
            {currentUser.badges.length} / {ALL_BADGES.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {ALL_BADGES.map((badge) => {
            const isUnlocked = currentUser.badges.includes(badge.id);
            return (
              <div
                key={badge.id}
                onClick={() => setSelectedBadgeId(badge.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition flex items-start gap-3.5 ${
                  isUnlocked
                    ? 'border-indigo-200 bg-gradient-to-br from-indigo-50/50 via-white to-purple-50/50 shadow-sm hover:border-indigo-400'
                    : 'border-slate-200/70 bg-slate-50/60 opacity-60 hover:opacity-80'
                }`}
              >
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${
                    isUnlocked
                      ? 'bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-500/20'
                      : 'bg-slate-200 text-slate-400'
                  }`}
                >
                  {isUnlocked ? (
                    <Award className="w-5 h-5" />
                  ) : (
                    <Lock className="w-4 h-4" />
                  )}
                </div>

                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <h5 className="font-extrabold text-xs text-slate-900">
                      {badge.name}
                    </h5>
                    <span className="text-[10px] font-bold text-amber-700">
                      +{badge.xpReward} XP
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    {badge.description}
                  </p>
                  <p className="text-[10px] text-indigo-600 font-medium pt-1">
                    Req: {badge.criteria}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Grid: Impact Score & Weekly Leaderboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* BrainBridge Impact Score Breakdown */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <HeartHandshake className="w-4 h-4 text-emerald-600" />
              <h3 className="text-base font-bold text-slate-900">
                Community Impact Score
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              An explainable metric of peer tutoring contributions
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 text-center">
            <span className="text-3xl font-black text-emerald-950">
              {currentUser.impactScore}
            </span>
            <span className="text-xs font-bold text-emerald-800 block mt-0.5">
              Impact Rating Points
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Transparent Calculation Formula:
            </p>
            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 font-mono text-[11px] text-slate-700">
              {impactDetails.formula}
            </div>

            <div className="space-y-1.5 pt-2">
              {impactDetails.breakdown.map((b, i) => (
                <div key={i} className="flex items-center justify-between text-slate-600 text-xs py-1 border-b border-slate-100">
                  <span>{b.label} ({b.value})</span>
                  <span className="font-bold text-emerald-700">+{b.points} pts</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Weekly Leaderboard */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-500" />
                University Campus Leaderboard
              </h3>
              <p className="text-xs text-slate-500">
                Weekly rankings based on verified tutoring, learning consistency, and reviews
              </p>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs font-bold">
              {(['all', 'learner', 'tutor'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setLeaderboardTab(t)}
                  className={`px-3 py-1 rounded-lg capitalize transition ${
                    leaderboardTab === t
                      ? 'bg-white text-indigo-700 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t === 'all' ? 'Overall' : `${t}s`}
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase font-bold text-[10px] tracking-wider">
                  <th className="pb-3 pl-2">Rank</th>
                  <th className="pb-3">Student Peer</th>
                  <th className="pb-3">Role</th>
                  <th className="pb-3">Rank Title</th>
                  <th className="pb-3">Badges</th>
                  <th className="pb-3 text-right pr-2">Weekly XP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLeaderboard.map((entry) => {
                  const isCurrent = entry.userId === currentUser.id;
                  return (
                    <tr
                      key={entry.userId}
                      className={`hover:bg-slate-50 transition ${
                        isCurrent ? 'bg-indigo-50/50 font-bold' : ''
                      }`}
                    >
                      <td className="py-3 pl-2">
                        <span
                          className={`w-6 h-6 rounded-full inline-flex items-center justify-center font-black ${
                            entry.rank === 1
                              ? 'bg-amber-100 text-amber-800'
                              : entry.rank === 2
                              ? 'bg-slate-200 text-slate-700'
                              : entry.rank === 3
                              ? 'bg-amber-50 text-amber-900'
                              : 'text-slate-500'
                          }`}
                        >
                          {entry.rank}
                        </span>
                      </td>
                      <td className="py-3">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={entry.avatar}
                            alt={entry.name}
                            className="w-8 h-8 rounded-full object-cover border border-slate-200"
                          />
                          <div>
                            <span className="font-extrabold text-slate-900">
                              {entry.name}
                            </span>
                            {isCurrent && (
                              <span className="ml-1.5 text-[9px] uppercase font-bold text-indigo-600 bg-indigo-100 px-1.5 py-0.2 rounded">
                                You
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3">
                        <span
                          className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                            entry.role === 'learner'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {entry.role}
                        </span>
                      </td>
                      <td className="py-3 text-slate-600 font-medium">
                        Lvl {entry.level} ({entry.levelTitle})
                      </td>
                      <td className="py-3 text-slate-600 font-medium">
                        {entry.badgeCount} badges
                      </td>
                      <td className="py-3 text-right pr-2 font-black text-indigo-700">
                        {entry.weeklyXP} XP
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

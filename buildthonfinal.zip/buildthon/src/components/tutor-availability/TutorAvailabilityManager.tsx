import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  ExternalLink,
  GraduationCap,
  MapPin,
  Plus,
  Trash2,
  Video,
} from 'lucide-react';
import { AvailabilitySlot, TutorProfile, UserProfile } from '../../types';

interface TutorAvailabilityManagerProps {
  currentUser: UserProfile;
  tutorProfile?: TutorProfile;
  slots: AvailabilitySlot[];
  onAddSlot: (slot: Omit<AvailabilitySlot, 'id'>) => void;
  onDeleteSlot: (slotId: string) => void;
  onUpdateProfile: (profile: Partial<TutorProfile>, userUpdates: Partial<UserProfile>) => void;
}

export const TutorAvailabilityManager: React.FC<TutorAvailabilityManagerProps> = ({
  currentUser,
  tutorProfile,
  slots,
  onAddSlot,
  onDeleteSlot,
  onUpdateProfile,
}) => {
  // New slot form state
  const [dayOfWeek, setDayOfWeek] = useState<string>('Monday');
  const [date, setDate] = useState<string>('2026-10-26');
  const [startTime, setStartTime] = useState<string>('14:00');
  const [endTime, setEndTime] = useState<string>('15:00');
  const [mode, setMode] = useState<'online' | 'in_person'>('online');
  const [locationOrLink, setLocationOrLink] = useState<string>(
    'https://meet.google.com/brainbridge-study-room'
  );

  // Profile edit state
  const [bio, setBio] = useState<string>(currentUser.bio || '');
  const [locationPref, setLocationPref] = useState<string>(
    tutorProfile?.locationPreference || 'CS Study Room 304 or Google Meet'
  );
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const mySlots = slots.filter((s) => s.tutorId === currentUser.id);

  const handleCreateSlot = (e: React.FormEvent) => {
    e.preventDefault();
    onAddSlot({
      tutorId: currentUser.id,
      dayOfWeek,
      date,
      startTime,
      endTime,
      mode,
      locationOrLink,
      isBooked: false,
    });
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(
      { locationPreference: locationPref },
      { bio }
    );
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold mb-2">
            <GraduationCap className="w-3.5 h-3.5" />
            Tutor Teaching Portal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Manage Availability &amp; Teaching Hours
          </h1>
          <p className="text-sm text-slate-600 max-w-xl mt-1 leading-relaxed">
            Publish your open weekly office hours and study slots. Students can request sessions directly from these slots with guaranteed conflict prevention.
          </p>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 font-semibold">
          ★ {tutorProfile?.rating.toFixed(1) || '5.0'} Rating &bull; {tutorProfile?.reviewCount || 0} Peer Reviews
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Create New Slot */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              Publish New Slot
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Add guaranteed available time windows for students to book
            </p>
          </div>

          <form onSubmit={handleCreateSlot} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Day of Week
              </label>
              <select
                value={dayOfWeek}
                onChange={(e) => setDayOfWeek(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 bg-white text-slate-800 font-medium outline-none focus:border-indigo-500"
              >
                {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(
                  (d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  )
                )}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Target Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 outline-none focus:border-indigo-500 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Start Time
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 outline-none focus:border-indigo-500 font-medium"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  End Time
                </label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 outline-none focus:border-indigo-500 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Tutoring Format
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('online');
                    setLocationOrLink('https://meet.google.com/brainbridge-study-room');
                  }}
                  className={`py-2 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                    mode === 'online'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Online Meet</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('in_person');
                    setLocationOrLink('CS Building Room 304');
                  }}
                  className={`py-2 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                    mode === 'in_person'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>On-Campus</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                {mode === 'online' ? 'Meeting Link' : 'Campus Location Room'}
              </label>
              <input
                type="text"
                value={locationOrLink}
                onChange={(e) => setLocationOrLink(e.target.value)}
                placeholder={
                  mode === 'online'
                    ? 'https://meet.google.com/...'
                    : 'Library Pod 4, CS Lab 202'
                }
                required
                className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 outline-none focus:border-indigo-500 font-medium"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold shadow-md shadow-emerald-600/20 transition active:scale-[0.98]"
            >
              Publish Available Slot
            </button>
          </form>
        </div>

        {/* Right Column: Published Slots List & Profile Edit */}
        <div className="lg:col-span-2 space-y-6">
          {/* Slots List */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Published Slots ({mySlots.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Active slots shown on your mentor profile
                </p>
              </div>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                {mySlots.filter((s) => !s.isBooked).length} Open for Booking
              </span>
            </div>

            {mySlots.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                You have not published any availability slots yet. Use the form on the left to add your first slot!
              </div>
            ) : (
              <div className="space-y-2.5">
                {mySlots.map((slot) => (
                  <div
                    key={slot.id}
                    className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 text-indigo-600 flex items-center justify-center font-bold">
                        <Calendar className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900">
                            {slot.dayOfWeek}, {slot.date}
                          </span>
                          <span
                            className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${
                              slot.isBooked
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {slot.isBooked ? 'Booked' : 'Available'}
                          </span>
                        </div>
                        <p className="text-slate-500 text-[11px] mt-0.5 flex items-center gap-2">
                          <span>{slot.startTime} - {slot.endTime}</span>
                          <span>&bull;</span>
                          <span className="truncate max-w-xs">{slot.locationOrLink}</span>
                        </p>
                      </div>
                    </div>

                    {!slot.isBooked && (
                      <button
                        onClick={() => onDeleteSlot(slot.id)}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                        title="Remove open slot"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Profile Bio & Preferences Edit */}
          <form
            onSubmit={handleSaveProfile}
            className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Tutor Introduction &amp; Meeting Preferences
                </h3>
                <p className="text-xs text-slate-500">
                  Visible to university students browsing for peer tutors
                </p>
              </div>
              {isSaved && (
                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Saved!
                </span>
              )}
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Short Introduction / Tutoring Philosophy
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Default Meeting Location Preference
                </label>
                <input
                  type="text"
                  value={locationPref}
                  onChange={(e) => setLocationPref(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 outline-none focus:border-indigo-500 font-medium"
                />
              </div>

              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm transition"
              >
                Update Profile Details
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

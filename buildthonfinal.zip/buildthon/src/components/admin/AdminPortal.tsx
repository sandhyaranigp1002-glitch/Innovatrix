import React, { useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  Award,
  BarChart3,
  BookOpen,
  Calendar,
  Check,
  CheckCircle,
  CheckCircle2,
  Clock,
  ExternalLink,
  Eye,
  EyeOff,
  FileSpreadsheet,
  FileText,
  Filter,
  GraduationCap,
  Info,
  Layers,
  Lock,
  LogOut,
  Play,
  Plus,
  RotateCcw,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  TrendingUp,
  UserCheck,
  UserX,
  Users2,
  Video,
  X,
  XCircle,
} from 'lucide-react';
import {
  ActivityLog,
  ApprovedPRN,
  ContentReport,
  DailyQuest,
  LearningCircle,
  SessionRequest,
  StudentVerificationRequest,
  TutorApplication,
  TutorProfile,
  UserProfile,
} from '../../types';
import { maskPRN } from '../../services/security';
import { api, AdminStats, ApiUser, CollegeInfo, TutorRecord, SubjectRecord } from '../../services/api';
import { RecordedLecturesHub } from '../lectures/RecordedLecturesHub';
import { OnlineLectureSessionsHub } from '../sessions/OnlineLectureSessionsHub';
import { DEPARTMENT_OPTIONS, ACADEMIC_YEAR_OPTIONS } from '../auth/AuthPage';

interface AdminPortalProps {
  currentUser: UserProfile;
  allUsers: UserProfile[];
  tutorProfiles: TutorProfile[];
  sessions: SessionRequest[];
  reports: ContentReport[];
  activityLogs: ActivityLog[];
  circles: LearningCircle[];
  quests: DailyQuest[];
  approvedPRNs: ApprovedPRN[];
  verificationRequests: StudentVerificationRequest[];
  tutorApplications: TutorApplication[];
  onUpdateReportStatus: (reportId: string, status: 'resolved' | 'dismissed') => void;
  onToggleUserStatus: (userId: string) => void;
  onToggleUserVerification: (userId: string) => void;
  onDeleteUser: (userId: string) => void;
  onApproveStudentVerification: (requestId: string) => void;
  onRejectStudentVerification: (requestId: string, reason: string) => void;
  onAddApprovedPRN: (data: { prn: string; studentName: string; email: string; department: string; academicYear: string }) => void;
  onImportApprovedPRNs: (prnList: { prn: string; studentName: string; email: string; department: string; academicYear: string }[]) => void;
  onApproveTutorApplication: (applicationId: string) => void;
  onRejectTutorApplication: (applicationId: string, reason: string) => void;
  onResetDemoData: () => void;
  onLogout: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  currentUser,
  allUsers,
  tutorProfiles,
  sessions,
  reports,
  activityLogs,
  circles,
  quests,
  approvedPRNs,
  verificationRequests,
  tutorApplications,
  onUpdateReportStatus,
  onToggleUserStatus,
  onToggleUserVerification,
  onDeleteUser,
  onApproveStudentVerification,
  onRejectStudentVerification,
  onAddApprovedPRN,
  onImportApprovedPRNs,
  onApproveTutorApplication,
  onRejectTutorApplication,
  onResetDemoData,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'students'
    | 'tutors'
    | 'subjects'
    | 'recorded-lectures'
    | 'online-sessions'
    | 'verifications'
    | 'tutor-apps'
    | 'reports'
    | 'logs'
    | 'analytics'
    | 'content'
  >('overview');

  // Database-backed states from persistent SQLite backend
  const [adminStats, setAdminStats] = useState<AdminStats | null>(null);
  const [dbStudents, setDbStudents] = useState<ApiUser[]>([]);
  const [dbTutors, setDbTutors] = useState<TutorRecord[]>([]);
  const [dbSubjects, setDbSubjects] = useState<SubjectRecord[]>([]);
  const [collegeInfo, setCollegeInfo] = useState<CollegeInfo | null>(null);

  // Add Tutor Modal State
  const [showAddTutorModal, setShowAddTutorModal] = useState(false);
  const [newTutorName, setNewTutorName] = useState('');
  const [newTutorSubject, setNewTutorSubject] = useState('DSA');
  const [newTutorEmail, setNewTutorEmail] = useState('');
  const [newTutorDept, setNewTutorDept] = useState(DEPARTMENT_OPTIONS[0]);
  const [isSubmittingTutor, setIsSubmittingTutor] = useState(false);

  // Load persistent database data
  const loadDatabaseData = async () => {
    try {
      const [stats, students, tuts, subjs, cInfo] = await Promise.all([
        api.getAdminStats().catch(() => null),
        api.getAdminStudents().catch(() => []),
        api.getTutors().catch(() => []),
        api.getSubjects().catch(() => []),
        api.getCollegeInfo().catch(() => null),
      ]);
      if (stats) setAdminStats(stats);
      setDbStudents(students);
      setDbTutors(tuts);
      setDbSubjects(subjs);
      if (cInfo) setCollegeInfo(cInfo);
    } catch (e) {
      console.error('Failed to load database admin records:', e);
    }
  };

  React.useEffect(() => {
    loadDatabaseData();
  }, []);

  const handleAddTutorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTutorName.trim() || !newTutorSubject.trim()) {
      alert('Please fill out Tutor Name and Subject.');
      return;
    }
    setIsSubmittingTutor(true);
    try {
      await api.createTutor({
        name: newTutorName.trim(),
        subject: newTutorSubject.trim(),
        email: newTutorEmail.trim() || `${newTutorName.toLowerCase().replace(/\s+/g, '.')}@brainbridge.edu`,
        department: newTutorDept,
        experience_years: 4,
        rating: 4.9,
      });
      await loadDatabaseData();
      setShowAddTutorModal(false);
      setNewTutorName('');
      setNewTutorEmail('');
    } catch (err: any) {
      alert(err.message || 'Failed to add tutor');
    } finally {
      setIsSubmittingTutor(false);
    }
  };

  const handleDeleteTutor = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this tutor record?')) return;
    try {
      await api.deleteTutor(id);
      await loadDatabaseData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete tutor');
    }
  };

  // Sub-tabs in PRN verification
  const [prnSubTab, setPrnSubTab] = useState<'requests' | 'roster'>('requests');
  const [revealedPRNIds, setRevealedPRNIds] = useState<Record<string, boolean>>({});

  // Search & Filter States
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'learner' | 'tutor'>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Modals state for PRN & Applications
  const [showAddPRNModal, setShowAddPRNModal] = useState(false);
  const [newPRNInput, setNewPRNInput] = useState({
    prn: '',
    studentName: '',
    email: '',
    department: 'Computer Science',
    academicYear: 'Freshman (1st Year)',
  });
  const [addPRNError, setAddPRNError] = useState<string | null>(null);

  const [showImportCSVModal, setShowImportCSVModal] = useState(false);
  const [csvText, setCsvText] = useState('');
  const [importResult, setImportResult] = useState<string | null>(null);

  const [rejectModalReqId, setRejectModalReqId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const [rejectTutorAppId, setRejectTutorAppId] = useState<string | null>(null);
  const [rejectTutorReason, setRejectTutorReason] = useState('');

  // Derived counts
  const studentCount = allUsers.filter((u) => u.role === 'learner').length;
  const tutorCount = allUsers.filter((u) => u.role === 'tutor').length;
  const totalSessions = sessions.length;
  const pendingRequests = sessions.filter((s) => s.status === 'pending').length;
  const pendingReports = reports.filter((r) => r.status === 'pending').length;
  const pendingVerifications = verificationRequests.filter((r) => r.status === 'pending').length;
  const pendingTutorApps = tutorApplications.filter((a) => a.status === 'pending').length;

  // Filter users
  const filteredUsers = allUsers.filter((u) => {
    if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
    if (userSearch) {
      const q = userSearch.toLowerCase();
      return (
        u.name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.department.toLowerCase().includes(q) ||
        (u.prn && u.prn.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const toggleRevealPRN = (id: string) => {
    setRevealedPRNIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAddPRNSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAddPRNError(null);
    try {
      onAddApprovedPRN(newPRNInput);
      setNewPRNInput({
        prn: '',
        studentName: '',
        email: '',
        department: 'Computer Science',
        academicYear: 'Freshman (1st Year)',
      });
      setShowAddPRNModal(false);
    } catch (err: any) {
      setAddPRNError(err.message || 'Failed to add PRN.');
    }
  };

  const handleCSVImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const lines = csvText.trim().split('\n');
    const parsedList: { prn: string; studentName: string; email: string; department: string; academicYear: string }[] = [];

    for (const line of lines) {
      const parts = line.split(',').map((p) => p.trim());
      if (parts.length >= 3 && parts[0].toUpperCase().startsWith('PRN-')) {
        parsedList.push({
          prn: parts[0],
          studentName: parts[1] || 'Student',
          email: parts[2] || `${parts[0].toLowerCase()}@campus.edu`,
          department: parts[3] || 'Engineering',
          academicYear: parts[4] || 'Undergraduate',
        });
      }
    }

    if (parsedList.length === 0) {
      setImportResult('No valid rows found. Please format as: PRN,Name,Email,Department,Year');
      return;
    }

    onImportApprovedPRNs(parsedList);
    setImportResult(`Successfully imported ${parsedList.length} student records into the approved roster.`);
    setTimeout(() => {
      setShowImportCSVModal(false);
      setImportResult(null);
      setCsvText('');
    }, 1500);
  };

  // Analytics data
  const registrationsData = [
    { month: 'May', students: 12, tutors: 4 },
    { month: 'Jun', students: 24, tutors: 7 },
    { month: 'Jul', students: 45, tutors: 12 },
    { month: 'Aug', students: 80, tutors: 20 },
    { month: 'Sep', students: 130, tutors: 32 },
    { month: 'Oct (Current)', students: 175, tutors: 41 },
  ];

  const popularSubjectsData = [
    { name: 'Python', sessions: 42, color: '#4F46E5' },
    { name: 'Data Structures', sessions: 38, color: '#7C3AED' },
    { name: 'DBMS', sessions: 25, color: '#06B6D4' },
    { name: 'Operating Systems', sessions: 20, color: '#10B981' },
    { name: 'Math / ML', sessions: 18, color: '#F59E0B' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-bold mb-2">
            <Shield className="w-3.5 h-3.5 text-purple-400" />
            <span>Campus Security & Registrar Control Center</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            BrainBridge Administrator Portal
          </h1>
          <p className="text-sm text-slate-300 max-w-xl mt-1 leading-relaxed">
            Welcome, <strong>{currentUser.name}</strong>. Monitor platform health, verify student PRN credentials, certify peer tutors, and audit institutional activities.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onResetDemoData}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Platform Store</span>
          </button>
          <button
            onClick={onLogout}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2 text-xs">
        {[
          { id: 'overview', label: 'Admin Overview & Stats', icon: BarChart3 },
          { id: 'students', label: `Manage Students (${dbStudents.length || allUsers.filter(u => u.role === 'learner').length})`, icon: Users2 },
          { id: 'tutors', label: `Manage Tutors (${dbTutors.length || 4})`, icon: UserCheck },
          { id: 'subjects', label: `Manage Subjects (${dbSubjects.length || 4})`, icon: BookOpen },
          { id: 'recorded-lectures', label: `Recorded Lectures (${adminStats?.totalRecordings || 4})`, icon: Video },
          { id: 'online-sessions', label: `Online Sessions (${adminStats?.totalSessions || 3})`, icon: Calendar },
          {
            id: 'verifications',
            label: `PRN Verifications (${pendingVerifications})`,
            icon: ShieldCheck,
            badge: pendingVerifications > 0,
          },
          {
            id: 'tutor-apps',
            label: `Tutor Applications (${pendingTutorApps})`,
            icon: GraduationCap,
            badge: pendingTutorApps > 0,
          },
          { id: 'reports', label: `Reports (${pendingReports})`, icon: ShieldAlert },
          { id: 'logs', label: `Audit Log (${activityLogs.length})`, icon: Activity },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {tab.badge && !isActive && (
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW METRICS & STATISTICS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Top KPI Metrics Row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Students
              </span>
              <span className="text-2xl font-black text-indigo-950 mt-1 block">
                {adminStats?.totalStudents ?? dbStudents.length ?? studentCount}
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold">Database Backed</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Approved Tutors
              </span>
              <span className="text-2xl font-black text-indigo-950 mt-1 block">
                {adminStats?.totalTutors ?? dbTutors.length ?? 4}
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold">100% Certified</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Active Subjects
              </span>
              <span className="text-2xl font-black text-indigo-950 mt-1 block">
                {adminStats?.totalSubjects ?? dbSubjects.length ?? 4}
              </span>
              <span className="text-[10px] text-indigo-600 font-semibold">DSA, Java, Py, DBMS</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Recorded Lectures
              </span>
              <span className="text-2xl font-black text-indigo-950 mt-1 block">
                {adminStats?.totalRecordings ?? 4}
              </span>
              <span className="text-[10px] text-indigo-600 font-semibold">Video Archive</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Online Sessions
              </span>
              <span className="text-2xl font-black text-indigo-950 mt-1 block">
                {adminStats?.totalSessions ?? 3}
              </span>
              <span className="text-[10px] text-emerald-600 font-semibold">Live &amp; Scheduled</span>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Pending PRNs
              </span>
              <span className="text-2xl font-black text-amber-600 mt-1 block">
                {pendingVerifications}
              </span>
              <span className="text-[10px] text-amber-700 font-semibold">Action Required</span>
            </div>
          </div>

          {/* Institutional Leadership & Principal Info Card (Requirement 6) */}
          <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-3xl p-6 text-white border border-indigo-900/50 shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center font-serif text-2xl font-bold shadow-md">
                🎓
              </div>
              <div>
                <div className="flex items-center gap-2 text-indigo-300 font-bold text-xs uppercase tracking-wider mb-0.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>College Information &bull; Institutional Leadership</span>
                </div>
                <div className="flex items-baseline gap-2.5">
                  <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                    {collegeInfo?.principal_name || 'Dr. Suhas Sapate Sir'}
                  </h3>
                  <span className="px-3 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-500/40 font-bold text-xs">
                    {collegeInfo?.principal_designation || 'Principal'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {collegeInfo?.institution_name || 'BrainBridge College of Engineering & Technology'}
                </p>
              </div>
            </div>

            <div className="text-right text-xs text-slate-400 hidden lg:block">
              <p className="font-semibold text-white">Central Campus Administration</p>
              <p className="text-[11px] text-indigo-300 mt-0.5">Accreditation &bull; Academic Board Approved</p>
            </div>
          </div>

          {/* Department-wise and Academic Year-wise Student Statistics (Requirement 5) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Department-wise Student Statistics */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-black text-slate-900 text-base">
                      Department-wise Student Statistics
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Enrolled student breakdown across academic engineering departments
                    </p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700">
                    Live SQL Aggregation
                  </span>
                </div>

                <div className="space-y-2.5">
                  {DEPARTMENT_OPTIONS.map((dept) => {
                    const deptMatch = adminStats?.departmentStats?.find(
                      (d) => d.department.toLowerCase() === dept.toLowerCase()
                    );
                    const count = deptMatch ? deptMatch.count : dbStudents.filter((s) => s.department === dept).length;
                    const totalStudentsCount = Math.max(1, adminStats?.totalStudents || dbStudents.length || 1);
                    const percent = Math.round((count / totalStudentsCount) * 100);

                    return (
                      <div key={dept} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-800 truncate max-w-[240px]" title={dept}>
                            {dept}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="font-black text-slate-900">{count} {count === 1 ? 'Student' : 'Students'}</span>
                            <span className="text-[10px] text-slate-400 font-medium">({percent}%)</span>
                          </div>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Academic Year-wise Student Statistics */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-black text-slate-900 text-base">
                      Academic Year-wise Student Statistics
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Distribution of enrolled student cohorts by current academic year
                    </p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700">
                    Cohort Roster
                  </span>
                </div>

                <div className="space-y-3">
                  {ACADEMIC_YEAR_OPTIONS.map((yr, idx) => {
                    const yrMatch = adminStats?.yearStats?.find(
                      (y) => y.academic_year.toLowerCase() === yr.toLowerCase()
                    );
                    const count = yrMatch ? yrMatch.count : dbStudents.filter((s) => s.academic_year === yr).length;
                    const totalStudentsCount = Math.max(1, adminStats?.totalStudents || dbStudents.length || 1);
                    const percent = Math.round((count / totalStudentsCount) * 100);

                    const colors = [
                      'bg-indigo-600',
                      'bg-violet-600',
                      'bg-emerald-600',
                      'bg-amber-600',
                    ];

                    return (
                      <div key={yr} className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-slate-900">
                            {yr} Cohort
                          </span>
                          <span className="font-black text-slate-900">
                            {count} {count === 1 ? 'Student' : 'Students'}
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div
                            className={`${colors[idx % colors.length]} h-full rounded-full transition-all duration-300`}
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <span>Semester {(idx * 2) + 1} - {(idx * 2) + 2}</span>
                          <span>{percent}% of student body</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Action Alerts */}
          {(pendingVerifications > 0 || pendingTutorApps > 0) && (
            <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">Administrative Action Items Pending</h4>
                  <p className="text-xs text-amber-800">
                    You have {pendingVerifications} student PRN verification requests and {pendingTutorApps} tutor certification applications awaiting decision.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {pendingVerifications > 0 && (
                  <button
                    onClick={() => {
                      setActiveTab('verifications');
                      setPrnSubTab('requests');
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-sm transition"
                  >
                    Verify Students ({pendingVerifications})
                  </button>
                )}
                {pendingTutorApps > 0 && (
                  <button
                    onClick={() => setActiveTab('tutor-apps')}
                    className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-sm transition"
                  >
                    Review Tutors ({pendingTutorApps})
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PRN VERIFICATIONS & ROSTER MANAGEMENT */}
      {activeTab === 'verifications' && (
        <div className="space-y-5">
          {/* Sub Navigation */}
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-2xl text-xs">
              <button
                onClick={() => setPrnSubTab('requests')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 ${
                  prnSubTab === 'requests'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Clock className="w-4 h-4 text-amber-500" />
                <span>Verification Requests Queue ({verificationRequests.length})</span>
              </button>
              <button
                onClick={() => setPrnSubTab('roster')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 ${
                  prnSubTab === 'roster'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Approved PRN Roster ({approvedPRNs.length})</span>
              </button>
            </div>

            {prnSubTab === 'roster' && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAddPRNModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Approved PRN</span>
                </button>
                <button
                  onClick={() => setShowImportCSVModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-sm"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Import CSV Roster</span>
                </button>
              </div>
            )}
          </div>

          {/* Privacy Note */}
          <div className="p-3.5 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-700 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-slate-500 shrink-0" />
              <span>
                <strong>Confidential Student Identifiers:</strong> PRNs are masked across public interfaces. Authorized administrators can inspect full values below strictly for identity verification.
              </span>
            </div>
            <span className="font-mono text-[10px] bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-500 shrink-0">
              RLS Policy: admin_only_prn_access
            </span>
          </div>

          {/* Sub-Tab 1: Verification Requests Queue */}
          {prnSubTab === 'requests' && (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    Student PRN Verification Requests
                  </h3>
                  <p className="text-xs text-slate-500">
                    Review and verify incoming Permanent Registration Numbers against official registrar data
                  </p>
                </div>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-800">
                  {pendingVerifications} Pending Decision
                </span>
              </div>

              {verificationRequests.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  No verification requests currently queued.
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {verificationRequests.map((req) => {
                    const isRevealed = revealedPRNIds[req.id];
                    return (
                      <div
                        key={req.id}
                        className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/70 transition"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2.5">
                            <span className="font-extrabold text-sm text-slate-900">
                              {req.studentName}
                            </span>
                            <span
                              className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                                req.status === 'approved'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : req.status === 'rejected'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {req.status === 'approved'
                                ? 'Verified'
                                : req.status === 'rejected'
                                ? 'Declined'
                                : 'Pending Verification'}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                            <span>Email: <strong className="text-slate-700">{req.email}</strong></span>
                            <span>Dept: <strong className="text-slate-700">{req.department}</strong></span>
                            <span>Year: <strong className="text-slate-700">{req.academicYear}</strong></span>
                            <span>Submitted: {new Date(req.submittedAt).toLocaleDateString()}</span>
                          </div>

                          {/* PRN Display with Reveal Toggle */}
                          <div className="flex items-center gap-2 pt-1">
                            <span className="text-xs font-semibold text-slate-500">PRN:</span>
                            <span className="font-mono text-xs font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-200">
                              {isRevealed ? req.prn : req.prnMasked}
                            </span>
                            <button
                              onClick={() => toggleRevealPRN(req.id)}
                              className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition"
                            >
                              {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              <span>{isRevealed ? 'Hide' : 'Reveal Full PRN'}</span>
                            </button>
                          </div>

                          {req.rejectionReason && (
                            <p className="text-xs text-rose-600 font-medium pt-1">
                              Declined reason: "{req.rejectionReason}" (by {req.reviewedBy})
                            </p>
                          )}
                        </div>

                        {/* Actions */}
                        {req.status === 'pending' ? (
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => onApproveStudentVerification(req.id)}
                              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-sm active:scale-95"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Verify &amp; Approve</span>
                            </button>
                            <button
                              onClick={() => {
                                setRejectModalReqId(req.id);
                                setRejectReason('');
                              }}
                              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-rose-50 hover:text-rose-700 border border-slate-200 text-slate-700 font-bold text-xs transition flex items-center gap-1.5"
                            >
                              <XCircle className="w-4 h-4" />
                              <span>Decline</span>
                            </button>
                          </div>
                        ) : (
                          <div className="text-xs text-slate-400 font-medium shrink-0">
                            Reviewed by {req.reviewedBy || 'Admin'}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Sub-Tab 2: Approved PRN Roster */}
          {prnSubTab === 'roster' && (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    Official College Approved PRN Database
                  </h3>
                  <p className="text-xs text-slate-500">
                    Pre-authorized student roster maintained by the university registrar
                  </p>
                </div>
                <span className="text-xs font-mono font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
                  Total Records: {approvedPRNs.length}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-3.5">PRN (Masked)</th>
                      <th className="p-3.5">Student Name</th>
                      <th className="p-3.5">College Email</th>
                      <th className="p-3.5">Department</th>
                      <th className="p-3.5">Year</th>
                      <th className="p-3.5">Registration Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {approvedPRNs.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/60 transition">
                        <td className="p-3.5 font-mono font-bold text-slate-900">
                          {item.prnMasked}
                        </td>
                        <td className="p-3.5 font-bold text-slate-800">{item.studentName}</td>
                        <td className="p-3.5 font-mono text-slate-600">{item.email}</td>
                        <td className="p-3.5">{item.department}</td>
                        <td className="p-3.5">{item.academicYear}</td>
                        <td className="p-3.5">
                          {item.isRegistered ? (
                            <span className="inline-flex items-center gap-1 font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                              <CheckCircle className="w-3 h-3 text-emerald-600" />
                              <span>Registered</span>
                            </span>
                          ) : (
                            <span className="font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
                              Unclaimed
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: TUTOR APPLICATIONS QUEUE */}
      {activeTab === 'tutor-apps' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-4">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Certified Peer Tutor Applications Queue
              </h3>
              <p className="text-xs text-slate-500">
                Evaluate student mentor applications before granting tutor permissions and slot publishing capabilities
              </p>
            </div>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-purple-100 text-purple-800">
              {pendingTutorApps} Pending Review
            </span>
          </div>

          {tutorApplications.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No tutor applications currently pending review.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {tutorApplications.map((app) => (
                <div key={app.id} className="p-5 space-y-3 hover:bg-slate-50/70 transition">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-base text-slate-900">
                          {app.studentName}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700">
                          Verified Student
                        </span>
                        <span
                          className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                            app.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : app.status === 'rejected'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-purple-100 text-purple-800'
                          }`}
                        >
                          {app.status === 'approved'
                            ? 'Certified'
                            : app.status === 'rejected'
                            ? 'Declined'
                            : 'Pending Decision'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {app.department} &bull; {app.email} &bull; Applied: {new Date(app.submittedAt).toLocaleDateString()}
                      </p>
                    </div>

                    {/* Actions */}
                    {app.status === 'pending' ? (
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => onApproveTutorApplication(app.id)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-sm active:scale-95"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Approve &amp; Certify Tutor</span>
                        </button>
                        <button
                          onClick={() => {
                            setRejectTutorAppId(app.id);
                            setRejectTutorReason('');
                          }}
                          className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-rose-50 hover:text-rose-700 border border-slate-200 text-slate-700 font-bold text-xs transition"
                        >
                          Decline
                        </button>
                      </div>
                    ) : (
                      <div className="text-xs text-slate-400 font-medium">
                        Reviewed by {app.reviewedBy || 'Admin'}
                      </div>
                    )}
                  </div>

                  {/* Subjects requested */}
                  <div className="flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="text-slate-500 font-semibold">Subjects:</span>
                    {app.subjects.map((s) => (
                      <span
                        key={s}
                        className="px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold text-[11px]"
                      >
                        {s}
                      </span>
                    ))}
                    <span className="text-slate-400 ml-2">&bull; Style: <strong className="text-slate-700">{app.teachingStyle}</strong></span>
                    <span className="text-slate-400">&bull; Credits: <strong className="text-slate-700">{app.hourlyCredits}/hr</strong></span>
                  </div>

                  {/* Qualifications Summary */}
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
                    <span className="font-bold text-slate-900 block mb-1">
                      Qualifications &amp; Coursework Standing:
                    </span>
                    <p className="italic leading-relaxed">{app.expertiseSummary}</p>
                  </div>

                  {app.rejectionReason && (
                    <p className="text-xs text-rose-600 font-semibold">
                      Declined reason: "{app.rejectionReason}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB: MANAGE STUDENTS (Database-backed from SQLite) */}
      {activeTab === 'students' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-4">
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider mb-0.5">
                <Users2 className="w-4 h-4" />
                <span>Central Student Directory</span>
              </div>
              <h3 className="font-black text-slate-900 text-base">
                Registered Student Records ({dbStudents.length})
              </h3>
              <p className="text-xs text-slate-500">
                All successfully registered students stored permanently in the university SQLite database
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter students by name, email, PRN..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs outline-none focus:border-indigo-400"
                />
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Student Name</th>
                  <th className="p-3.5">Student ID / PRN</th>
                  <th className="p-3.5">Email Address</th>
                  <th className="p-3.5">Department</th>
                  <th className="p-3.5">Academic Year</th>
                  <th className="p-3.5">Semester</th>
                  <th className="p-3.5">Registration Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {dbStudents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400 text-xs font-medium">
                      No student records found in database. New registrations will appear here permanently.
                    </td>
                  </tr>
                ) : (
                  dbStudents
                    .filter((s) => {
                      if (!userSearch) return true;
                      const q = userSearch.toLowerCase();
                      return (
                        s.name.toLowerCase().includes(q) ||
                        s.email.toLowerCase().includes(q) ||
                        (s.prn && s.prn.toLowerCase().includes(q)) ||
                        s.department.toLowerCase().includes(q)
                      );
                    })
                    .map((student) => (
                      <tr key={student.id} className="hover:bg-slate-50/60 transition">
                        <td className="p-3.5 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-violet-500 text-white font-bold flex items-center justify-center text-xs">
                            {student.name.charAt(0)}
                          </div>
                          <span className="font-bold text-slate-900">{student.name}</span>
                        </td>
                        <td className="p-3.5 font-mono text-xs font-bold text-indigo-700">
                          {student.prn || 'N/A'}
                        </td>
                        <td className="p-3.5 text-slate-600 font-medium">
                          {student.email}
                        </td>
                        <td className="p-3.5">
                          <span className="truncate block max-w-[200px]" title={student.department}>
                            {student.department}
                          </span>
                        </td>
                        <td className="p-3.5 font-medium text-slate-800">
                          {student.academic_year}
                        </td>
                        <td className="p-3.5 text-slate-600">
                          {student.semester || 'Semester 1'}
                        </td>
                        <td className="p-3.5">
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Registered &bull; Verified
                          </span>
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: MANAGE TUTORS (Requirement 7) */}
      {activeTab === 'tutors' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider mb-0.5">
                <UserCheck className="w-4 h-4" />
                <span>Faculty &amp; Tutor Management Roster</span>
              </div>
              <h3 className="font-black text-slate-900 text-lg">
                Certified Tutors &amp; Subject Assignments ({dbTutors.length})
              </h3>
              <p className="text-xs text-slate-500">
                Manage university-approved course tutors and their assigned engineering subjects
              </p>
            </div>

            <button
              onClick={() => setShowAddTutorModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition active:scale-95 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Tutor</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Sr. No.</th>
                  <th className="p-3.5">Tutor Name</th>
                  <th className="p-3.5">Assigned Subject</th>
                  <th className="p-3.5">Official Email</th>
                  <th className="p-3.5">Department</th>
                  <th className="p-3.5">Rating</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {dbTutors.map((tutor, idx) => (
                  <tr key={tutor.id} className="hover:bg-slate-50/60 transition">
                    <td className="p-3.5 font-mono font-bold text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 font-bold flex items-center justify-center text-xs">
                          {tutor.name.charAt(0)}
                        </div>
                        <span className="font-bold text-slate-900 text-sm">{tutor.name}</span>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-black text-xs">
                        {tutor.subject}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono text-slate-600">
                      {tutor.email || `${tutor.name.toLowerCase().replace(/\s+/g, '.')}@brainbridge.edu`}
                    </td>
                    <td className="p-3.5 text-slate-600">
                      {tutor.department}
                    </td>
                    <td className="p-3.5 font-bold text-amber-600">
                      ⭐ {tutor.rating || '4.9'}
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => handleDeleteTutor(tutor.id)}
                        className="px-2.5 py-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="Delete tutor record"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: MANAGE SUBJECTS */}
      {activeTab === 'subjects' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider mb-0.5">
                <BookOpen className="w-4 h-4" />
                <span>Course Curriculum Matrix</span>
              </div>
              <h3 className="font-black text-slate-900 text-lg">
                Curriculum Subjects ({dbSubjects.length || 4})
              </h3>
              <p className="text-xs text-slate-500">
                Official college course offerings, credit values, and department mappings
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {(dbSubjects.length > 0
              ? dbSubjects
              : [
                  { id: 'sub_1', code: 'CS-201', name: 'Data Structures & Algorithms (DSA)', department: 'Computer Science and Engineering (CSE)', semester: 'Semester 3', credits: 4 },
                  { id: 'sub_2', code: 'CS-202', name: 'Object-Oriented Programming with Java', department: 'Computer Science and Engineering (CSE)', semester: 'Semester 4', credits: 4 },
                  { id: 'sub_3', code: 'IT-102', name: 'Python for Engineering & Data Science', department: 'Information Technology (IT)', semester: 'Semester 2', credits: 3 },
                  { id: 'sub_4', code: 'CS-301', name: 'Database Management Systems (DBMS)', department: 'Computer Science and Engineering (CSE)', semester: 'Semester 5', credits: 4 },
                ]
            ).map((sub) => (
              <div key={sub.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-white text-indigo-700 border border-indigo-200">
                      {sub.code}
                    </span>
                    <span className="text-[11px] font-bold text-slate-500">
                      {sub.credits} Credits
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm leading-snug">{sub.name}</h4>
                  <p className="text-xs text-slate-500 mt-1">{sub.department}</p>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs text-slate-600">
                  <span>{sub.semester}</span>
                  <span className="font-semibold text-emerald-600">Active Course</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: MANAGE RECORDED LECTURES (Requirement 8) */}
      {activeTab === 'recorded-lectures' && (
        <div className="space-y-4">
          <RecordedLecturesHub canManage={true} />
        </div>
      )}

      {/* TAB: MANAGE ONLINE LECTURE SESSIONS (Requirement 9) */}
      {activeTab === 'online-sessions' && (
        <div className="space-y-4">
          <OnlineLectureSessionsHub canManage={true} />
        </div>
      )}

      {/* TAB 7: ANALYTICS & GROWTH */}
      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900">
              Verified Student Registrations vs Approved Tutors
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={registrationsData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} />
                  <Tooltip />
                  <Area type="monotone" dataKey="students" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.2} name="Students" />
                  <Area type="monotone" dataKey="tutors" stroke="#10B981" fill="#10B981" fillOpacity={0.2} name="Tutors" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900">
              Most Requested Tutoring Topics (Session Volume)
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={popularSubjectsData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E2E8F0" />
                  <XAxis type="number" stroke="#94A3B8" fontSize={11} />
                  <YAxis type="category" dataKey="name" stroke="#94A3B8" fontSize={11} width={100} />
                  <Tooltip />
                  <Bar dataKey="sessions" radius={[0, 8, 8, 0]}>
                    {popularSubjectsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: CONTENT & QUESTS */}
      {activeTab === 'content' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Active Campus Learning Circles</h3>
            <div className="space-y-3">
              {circles.map((c) => (
                <div key={c.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{c.name}</span>
                    <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                      {c.members.length} members
                    </span>
                  </div>
                  <p className="text-slate-500 mt-1">{c.subject} &bull; Goal: {c.learningGoal}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Daily Quest Challenges</h3>
            <div className="space-y-3">
              {quests.map((q) => (
                <div key={q.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block">{q.title}</span>
                    <span className="text-slate-500">{q.description}</span>
                  </div>
                  <span className="font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded-lg">
                    +{q.xpReward} XP
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 9: SAFETY REPORTS */}
      {activeTab === 'reports' && (
        <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Campus Safety &amp; Content Reports ({reports.length})
          </h3>
          <div className="space-y-3">
            {reports.map((report) => (
              <div
                key={report.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs flex items-start justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900">
                      Target: {report.targetName}
                    </span>
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                        report.status === 'pending'
                          ? 'bg-amber-100 text-amber-800'
                          : report.status === 'resolved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {report.status}
                    </span>
                  </div>
                  <p className="text-slate-600 italic">"{report.reason}"</p>
                  <p className="text-[11px] text-slate-400">
                    Reported by <strong>{report.reporterName}</strong> on{' '}
                    {new Date(report.createdAt).toLocaleDateString()}
                  </p>
                </div>

                {report.status === 'pending' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onUpdateReportStatus(report.id, 'resolved')}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition flex items-center gap-1"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Action &amp; Resolve</span>
                    </button>
                    <button
                      onClick={() => onUpdateReportStatus(report.id, 'dismissed')}
                      className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold transition"
                    >
                      Dismiss
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 10: AUDIT LOGS */}
      {activeTab === 'logs' && (
        <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Security &amp; Institutional Audit Trail ({activityLogs.length} events)
            </h3>
            <span className="text-xs font-mono text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
              PostgreSQL Table: public.audit_logs
            </span>
          </div>

          <div className="space-y-2">
            {activityLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between"
              >
                <div>
                  <span className="font-extrabold text-slate-900">{log.action}: </span>
                  <span className="text-slate-600 ml-1">{log.details}</span>
                  <span className="text-[10px] text-indigo-600 ml-2 font-semibold">
                    by {log.actorName} ({log.actorRole})
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  {new Date(log.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  })}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Approved PRN Modal */}
      {showAddPRNModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-base">Add Approved Student PRN</h3>
              <button
                onClick={() => setShowAddPRNModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {addPRNError && (
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{addPRNError}</span>
              </div>
            )}

            <form onSubmit={handleAddPRNSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Permanent Registration Number (PRN) *
                </label>
                <input
                  type="text"
                  placeholder="e.g. PRN-2025-5041"
                  value={newPRNInput.prn}
                  onChange={(e) =>
                    setNewPRNInput({ ...newPRNInput, prn: e.target.value.toUpperCase() })
                  }
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 uppercase font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Student Full Name *</label>
                <input
                  type="text"
                  placeholder="Student Name"
                  value={newPRNInput.studentName}
                  onChange={(e) =>
                    setNewPRNInput({ ...newPRNInput, studentName: e.target.value })
                  }
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Student Email (Any email accepted) *</label>
                <input
                  type="email"
                  placeholder="e.g. student@gmail.com, campus.edu"
                  value={newPRNInput.email}
                  onChange={(e) =>
                    setNewPRNInput({ ...newPRNInput, email: e.target.value })
                  }
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Department</label>
                  <input
                    type="text"
                    value={newPRNInput.department}
                    onChange={(e) =>
                      setNewPRNInput({ ...newPRNInput, department: e.target.value })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Academic Year</label>
                  <input
                    type="text"
                    value={newPRNInput.academicYear}
                    onChange={(e) =>
                      setNewPRNInput({ ...newPRNInput, academicYear: e.target.value })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddPRNModal(false)}
                  className="flex-1 py-2 rounded-xl border border-slate-200 font-bold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
                >
                  Save to Roster
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Import CSV Modal */}
      {showImportCSVModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-base">Import Approved PRN CSV Roster</h3>
              <button
                onClick={() => setShowImportCSVModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Paste comma-separated rows. Format: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">PRN,Name,Email,Department,Year</code>
            </p>

            {importResult && (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                {importResult}
              </div>
            )}

            <form onSubmit={handleCSVImportSubmit} className="space-y-3 text-xs">
              <textarea
                rows={6}
                value={csvText}
                onChange={(e) => setCsvText(e.target.value)}
                placeholder={`PRN-2025-5011, Maya Lin, maya.l@campus.edu, Computer Science, Freshman\nPRN-2025-5012, Sam Wilson, sam.w@campus.edu, Software Eng, Sophomore\nPRN-2025-5013, Aisha Khan, aisha.k@campus.edu, Data Science, Junior`}
                className="w-full p-3 rounded-xl border border-slate-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
              />

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowImportCSVModal(false)}
                  className="flex-1 py-2 rounded-xl border border-slate-200 font-bold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Process &amp; Import
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject Student PRN Verification Modal */}
      {rejectModalReqId && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Decline PRN Verification</h3>
            <p className="text-xs text-slate-500">
              Provide a reason for declining this student verification request.
            </p>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. PRN does not match the active college registrar roster for the 2026 academic term."
              required
              className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-rose-500 resize-none"
            />
            <div className="flex gap-2">
              <button
                onClick={() => setRejectModalReqId(null)}
                className="flex-1 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onRejectStudentVerification(rejectModalReqId, rejectReason || 'PRN verification declined.');
                  setRejectModalReqId(null);
                }}
                className="flex-1 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl"
              >
                Confirm Decline
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Tutor Application Modal */}
      {rejectTutorAppId && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Decline Tutor Application</h3>
            <p className="text-xs text-slate-500">
              Provide feedback for why this tutor application cannot be certified at this time.
            </p>
            <textarea
              rows={3}
              value={rejectTutorReason}
              onChange={(e) => setRejectTutorReason(e.target.value)}
              placeholder="e.g. Minimum grade requirement (A- in subject) not documented. Please re-apply next term."
              required
              className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:border-rose-500 resize-none"
            />
            <div className="flex gap-2">
              <button
                onClick={() => setRejectTutorAppId(null)}
                className="flex-1 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onRejectTutorApplication(rejectTutorAppId, rejectTutorReason || 'Application not certified.');
                  setRejectTutorAppId(null);
                }}
                className="flex-1 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl"
              >
                Confirm Decline
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Destructive Action Modal */}
      {confirmDeleteId && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95">
            <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">Confirm Account Deletion</h3>
            <p className="text-xs text-slate-500 mt-1">
              Are you sure you want to remove this user? All their slots and session bookings will be purged.
            </p>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setConfirmDeleteId(null)}
                className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteUser(confirmDeleteId);
                  setConfirmDeleteId(null);
                }}
                className="flex-1 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl"
              >
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Tutor Modal (Requirement 7) */}
      {showAddTutorModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-base">Add Certified Tutor</h3>
              </div>
              <button
                onClick={() => setShowAddTutorModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddTutorSubmit} className="space-y-4 pt-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Tutor Full Name *</label>
                <input
                  type="text"
                  value={newTutorName}
                  onChange={(e) => setNewTutorName(e.target.value)}
                  placeholder="e.g. Prof. Arvind Sharma"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800 font-medium focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Assigned Subject *</label>
                <input
                  type="text"
                  value={newTutorSubject}
                  onChange={(e) => setNewTutorSubject(e.target.value)}
                  placeholder="e.g. DSA, Java, Python, DBMS"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800 font-medium focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Official University Email</label>
                <input
                  type="email"
                  value={newTutorEmail}
                  onChange={(e) => setNewTutorEmail(e.target.value)}
                  placeholder="tutor.name@brainbridge.edu"
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800 font-medium focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Department *</label>
                <select
                  value={newTutorDept}
                  onChange={(e) => setNewTutorDept(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-slate-800 font-medium focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  {DEPARTMENT_OPTIONS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddTutorModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingTutor}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-md shadow-indigo-600/20 disabled:opacity-50"
                >
                  {isSubmittingTutor ? 'Saving...' : 'Add Tutor Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

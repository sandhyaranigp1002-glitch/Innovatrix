import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  ArrowUpRight, 
  ArrowDownLeft, 
  RefreshCcw, 
  ShieldCheck, 
  Sparkles, 
  BookOpen, 
  GraduationCap, 
  History, 
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  Gift
} from 'lucide-react';
import { storage } from '../../services/storage';
import { CreditTransaction, UserProfile } from '../../types';

interface SkillExchangeHubProps {
  currentUser?: UserProfile;
  onNavigateToDiscover?: () => void;
  onNavigateToTutorApply?: () => void;
}

export const SkillExchangeHub: React.FC<SkillExchangeHubProps> = ({
  currentUser,
  onNavigateToDiscover,
  onNavigateToTutorApply
}) => {
  const activeUser = currentUser || storage.getCurrentUser();
  const [balance, setBalance] = useState<number>(0);
  const [transactions, setTransactions] = useState<CreditTransaction[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [bonusClaimedToday, setBonusClaimedToday] = useState<boolean>(false);

  const loadData = () => {
    if (!activeUser) return;
    const currentProfile = storage.getUserProfile(activeUser.id);
    setBalance(currentProfile?.creditBalance ?? 5);

    const history = storage.getCreditTransactions(activeUser.id);
    setTransactions(history);

    // Check if daily bonus was already claimed today
    const today = new Date().toISOString().split('T')[0];
    const claimed = history.some(t => 
      t.type === 'bonus' && 
      t.description.includes('Daily') && 
      (t.createdAt?.startsWith(today) || t.timestamp?.startsWith(today))
    );
    setBonusClaimedToday(claimed);
  };

  useEffect(() => {
    loadData();
  }, [activeUser?.id]);

  // Calculate lifetime earned and spent
  const totalEarned = transactions
    .filter(t => t.amount > 0)
    .reduce((acc: number, t: CreditTransaction) => acc + t.amount, 0);

  const totalSpent = Math.abs(
    transactions
      .filter(t => t.amount < 0)
      .reduce((acc: number, t: CreditTransaction) => acc + t.amount, 0)
  );

  const handleClaimDailyBonus = () => {
    if (!activeUser || bonusClaimedToday) return;

    const tx = storage.addCreditTransaction({
      userId: activeUser.id,
      amount: 1,
      type: 'bonus',
      description: 'Daily Peer Learning Grant (Active Campus Citizen)'
    });

    if (tx) {
      storage.awardXP(activeUser.id, 10, 'Claimed daily platform credit');
      setToastMessage('Claimed +1 Skill Credit & +10 XP!');
      setBonusClaimedToday(true);
      loadData();
      setTimeout(() => setToastMessage(null), 3500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 bg-emerald-600 text-white font-medium rounded-xl shadow-xl shadow-emerald-500/20 animate-bounce">
          <Sparkles className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950/70 border border-amber-500/30 p-6 md:p-8 backdrop-blur-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 mb-3">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              Reciprocal Peer Learning Economy
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
              Skill Exchange Credits
            </h1>
            <p className="mt-1 text-slate-300 text-sm md:text-base max-w-2xl">
              Teach what you excel at to earn learning credits. Spend earned credits to book peer tutoring in challenging courses.
              A fair, zero-cash academic economy that empowers every verified college student.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={handleClaimDailyBonus}
              disabled={bonusClaimedToday}
              className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-sm transition-all shadow-lg ${
                bonusClaimedToday
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/25 cursor-pointer'
              }`}
            >
              <Gift className="w-4 h-4" />
              {bonusClaimedToday ? 'Bonus Claimed Today' : 'Daily Grant (+1 Credit)'}
            </button>
          </div>
        </div>

        {/* Regulatory Disclaimer */}
        <div className="relative z-10 mt-6 pt-4 border-t border-amber-500/20 flex items-center gap-2 text-xs text-amber-200/80">
          <HelpCircle className="w-3.5 h-3.5 shrink-0" />
          <span>
            Institutional Notice: Skill Exchange Credits are non-monetary virtual points restricted solely to booking peer tutoring and study sessions on BrainBridge.
          </span>
        </div>
      </div>

      {/* Balance Showcase & Economics Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Balance Card */}
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-amber-500/30 p-6 md:p-8 backdrop-blur-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">Available Balance</span>
              <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Coins className="w-6 h-6" />
              </div>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-5xl font-black text-white font-mono">{balance}</span>
              <span className="text-lg font-bold text-amber-400">Credits</span>
            </div>

            <p className="mt-2 text-xs text-slate-400">
              Valid for {balance} peer tutoring sessions (1 credit per approved booking).
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-slate-800/80 grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-slate-400 mb-1 flex items-center gap-1">
                <ArrowUpRight className="w-3 h-3 text-emerald-400" /> Lifetime Earned
              </div>
              <div className="text-lg font-bold text-emerald-400 font-mono">+{totalEarned}</div>
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-1 flex items-center gap-1">
                <ArrowDownLeft className="w-3 h-3 text-red-400" /> Lifetime Spent
              </div>
              <div className="text-lg font-bold text-red-400 font-mono">-{totalSpent}</div>
            </div>
          </div>
        </div>

        {/* Economy Rules & Value Matrix */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900/80 border border-slate-800 p-6 md:p-8 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-400" />
            Skill Credit Exchange Matrix
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-white text-sm">Teach a Session</span>
                <span className="text-sm font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  +2 Credits
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Complete an approved 45-min peer tutoring session. Credits are credited upon completion.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-white text-sm">Book a Peer Tutor</span>
                <span className="text-sm font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  -1 Credit
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Escrowed during request submission. Held securely until tutor acceptance.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-white text-sm">Session Cancelled / Declined</span>
                <span className="text-sm font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                  100% Refund
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Instant automatic refund back to your balance if session cannot take place.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-white text-sm">Campus Citizen Grants</span>
                <span className="text-sm font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                  +1 to +5
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Awarded for PRN verification (+5), daily check-ins (+1), and weekly study quest completions.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="mt-6 pt-5 border-t border-slate-800 flex flex-wrap items-center gap-3">
            <button
              onClick={onNavigateToDiscover}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5" />
              Book Tutoring (-1 Credit)
            </button>
            <button
              onClick={onNavigateToTutorApply}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
            >
              <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
              Teach to Earn (+2 Credits)
            </button>
          </div>
        </div>
      </div>

      {/* Transaction History Ledger */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 md:p-8 backdrop-blur-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <History className="w-5 h-5 text-amber-400" />
              Credit Transaction Ledger ({transactions.length})
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Cryptographically validated balance transitions logged in sequence
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
            Ledger Synchronized
          </span>
        </div>

        {transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/60 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Description</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {transactions.map(tx => {
                  const isPositive = tx.amount > 0;
                  const dateStr = tx.createdAt || tx.timestamp;
                  return (
                    <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <div className={`p-1.5 rounded-lg ${
                            isPositive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                          }`}>
                            {isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownLeft className="w-3.5 h-3.5" />}
                          </div>
                          <span className="font-semibold capitalize text-slate-200">
                            {tx.type.replace('_', ' ')}
                          </span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-300">
                        <div className="flex items-center gap-2">
                          <span>{tx.description}</span>
                          {tx.isDemoSample && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              SAMPLE
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap font-mono">
                        {dateStr ? new Date(dateStr).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        }) : 'Recent'}
                      </td>

                      <td className="py-3.5 px-4 text-right whitespace-nowrap font-mono font-bold">
                        <span className={`text-sm ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
                          {isPositive ? `+${tx.amount}` : tx.amount} 🪙
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12 text-slate-500">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No credit transactions recorded yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

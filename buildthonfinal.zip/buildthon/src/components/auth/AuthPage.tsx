import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Eye,
  EyeOff,
  GraduationCap,
  KeyRound,
  Lock,
  Mail,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  User,
  Users2,
  Zap,
} from 'lucide-react';
import { UserRole, UserProfile } from '../../types';
import { LocalStorageAdapter } from '../../services/storage';
import { maskPRN } from '../../services/security';
import { api } from '../../services/api';

export const DEPARTMENT_OPTIONS = [
  'Computer Science and Engineering (CSE)',
  'Artificial Intelligence and Machine Learning (AI/ML)',
  'Electronics and Telecommunication Engineering (ENTC)',
  'Electrical Engineering',
  'Mechanical Engineering',
  'Civil Engineering',
  'Information Technology (IT)',
  'Other',
];

export const ACADEMIC_YEAR_OPTIONS = [
  'First Year',
  'Second Year',
  'Third Year',
  'Final Year',
];

export const SEMESTER_OPTIONS = [
  'Semester 1',
  'Semester 2',
  'Semester 3',
  'Semester 4',
  'Semester 5',
  'Semester 6',
  'Semester 7',
  'Semester 8',
];

interface AuthPageProps {
  initialRole?: UserRole;
  onSuccess: (role: UserRole) => void;
  onCancelToLanding?: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({
  initialRole = 'learner',
  onSuccess,
  onCancelToLanding,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [selectedRole, setSelectedRole] = useState<UserRole>(
    initialRole === 'admin' ? 'admin' : initialRole === 'tutor' ? 'tutor' : 'learner'
  );
  const [isAdminPortalMode, setIsAdminPortalMode] = useState<boolean>(initialRole === 'admin');

  // Login form state
  const [loginEmail, setLoginEmail] = useState(
    initialRole === 'admin' ? 'admin@brainbridge.edu' : ''
  );
  const [loginPassword, setLoginPassword] = useState(
    initialRole === 'admin' ? 'admin123' : ''
  );
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Register form state (Students)
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPRN, setRegPRN] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regDepartment, setRegDepartment] = useState(DEPARTMENT_OPTIONS[0]);
  const [regYear, setRegYear] = useState(ACADEMIC_YEAR_OPTIONS[0]);
  const [regSemester, setRegSemester] = useState(SEMESTER_OPTIONS[0]);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);
  const collegeConfig = LocalStorageAdapter.getSecurityConfig();

  // Handle Role Selection on login view
  const handleSelectRole = (role: UserRole) => {
    setSelectedRole(role);
    setErrorMessage('');
    setSuccessNotice(null);
    if (role === 'learner') {
      setIsAdminPortalMode(false);
      setLoginEmail('');
      setLoginPassword('');
    } else if (role === 'tutor') {
      setIsAdminPortalMode(false);
      setLoginEmail('');
      setLoginPassword('');
    } else if (role === 'admin') {
      setIsAdminPortalMode(true);
      setLoginEmail('admin@brainbridge.edu');
      setLoginPassword('admin123');
    }
  };

  // Instant 1-Click Demo Login for Evaluators
  const handleInstantDemoLogin = async (email: string, pass: string, role: UserRole) => {
    setIsLoading(true);
    setErrorMessage('');
    setSuccessNotice(null);
    try {
      const res = await api.login(email, pass);
      setIsLoading(false);
      onSuccess(res.user.role === 'admin' ? 'admin' : res.user.role === 'tutor' ? 'tutor' : 'learner');
    } catch (err: any) {
      // Fallback to local adapter if server not reachable
      try {
        const { user } = LocalStorageAdapter.login(email, pass, role);
        setIsLoading(false);
        onSuccess(user.role);
      } catch (e: any) {
        setIsLoading(false);
        setErrorMessage(e.message || 'Login failed.');
      }
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim() || !loginPassword.trim()) {
      setErrorMessage('Please enter both your email address and password.');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');
    setSuccessNotice(null);

    try {
      // 1. Authenticate with backend SQLite database
      const res = await api.login(loginEmail.trim(), loginPassword);

      // 2. Synchronize local profile state
      try {
        LocalStorageAdapter.login(
          loginEmail.trim(),
          loginPassword,
          isAdminPortalMode ? 'admin' : (res.user.role === 'admin' ? 'admin' : res.user.role === 'tutor' ? 'tutor' : 'learner')
        );
      } catch (localErr) {
        const fallbackUser: UserProfile = {
          id: res.user.id,
          name: res.user.name,
          email: res.user.email,
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
          role: res.user.role === 'admin' ? 'admin' : res.user.role === 'tutor' ? 'tutor' : 'learner',
          department: res.user.department || 'Computer Science and Engineering (CSE)',
          academicYear: res.user.academic_year || 'First Year',
          semester: res.user.semester || 'Semester 1',
          prn: res.user.prn || '',
          prnMasked: res.user.prn ? maskPRN(res.user.prn) : '',
          bio: res.user.bio || '',
          xp: 100,
          level: 1,
          levelTitle: 'Student Learner',
          streakDays: 1,
          bestStreak: 1,
          lastActiveDate: new Date().toISOString().split('T')[0],
          impactScore: 0,
          verified: true,
          badges: [],
          status: 'active',
          verificationStatus: 'approved',
          isTutorApproved: res.user.role === 'tutor',
          creditBalance: 10,
          languages: ['English'],
          themePreference: 'light',
          optOutOfLeaderboard: false,
        };
        const users = LocalStorageAdapter.getUsers();
        if (!users.some((u) => u.email.toLowerCase() === res.user.email.toLowerCase())) {
          users.push(fallbackUser);
          LocalStorageAdapter.saveUsers(users);
        }
        LocalStorageAdapter.setCurrentUserId(fallbackUser.id);
      }

      setIsLoading(false);
      const targetRole: UserRole =
        res.user.role === 'admin' ? 'admin' : res.user.role === 'tutor' ? 'tutor' : 'learner';
      onSuccess(targetRole);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err.message || 'Login failed. Please verify your credentials.');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessNotice(null);

    // 1. Required fields validation
    if (
      !regName.trim() ||
      !regEmail.trim() ||
      !regPRN.trim() ||
      !regPassword.trim() ||
      !regConfirmPassword.trim() ||
      !regDepartment ||
      !regYear
    ) {
      setErrorMessage('All required fields must be completed. Please fill out the full form.');
      return;
    }

    // 2. Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(regEmail.trim())) {
      setErrorMessage('Please enter a valid email address (e.g. name@domain.com or student@college.edu).');
      return;
    }

    // 3. Password matching validation
    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Password and Confirm Password do not match. Please verify.');
      return;
    }

    if (regPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    setIsLoading(true);

    try {
      // Call backend SQLite persistent registration
      await api.register({
        name: regName.trim(),
        email: regEmail.trim(),
        prn: regPRN.trim(),
        password: regPassword,
        confirmPassword: regConfirmPassword,
        department: regDepartment,
        academicYear: regYear,
        semester: regSemester,
      });

      // Synchronize local adapter so offline cache remains harmonious
      try {
        LocalStorageAdapter.register({
          name: regName.trim(),
          email: regEmail.trim(),
          prn: regPRN.trim(),
          password: regPassword,
          department: regDepartment,
          academicYear: regYear,
          bio: '',
        });
      } catch (ignored) {}

      setIsLoading(false);

      // Workflow requirement: Registration -> Successful Registration Message -> Login Page -> Enter Credentials -> Student Dashboard
      // Do NOT auto-login. Do NOT open dashboard immediately.
      setLoginEmail(regEmail.trim());
      setLoginPassword('');
      setSuccessNotice('🎉 Registration Successful! Please enter your credentials to log in.');
      setMode('login');

      // Clear register form fields
      setRegName('');
      setRegPRN('');
      setRegPassword('');
      setRegConfirmPassword('');
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err.message || 'Registration failed.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8 selection:bg-indigo-500 selection:text-white">
      {/* Top Brand Bar */}
      <div className="max-w-6xl mx-auto w-full flex items-center justify-between py-2">
        <div
          className="flex items-center gap-3 cursor-pointer"
          onClick={onCancelToLanding}
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
            <svg className="w-6 h-6" viewBox="0 0 32 32" fill="none">
              <path
                d="M8 24L16 8L24 24"
                stroke="#E0E7FF"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="8" cy="24" r="3" fill="#A5B4FC" />
              <circle cx="24" cy="24" r="3" fill="#A5B4FC" />
              <circle cx="16" cy="8" r="3.5" fill="#FFFFFF" />
              <path d="M16 8V24" stroke="#FFFFFF" strokeWidth="2" strokeDasharray="2 2" />
            </svg>
          </div>
          <div>
            <span className="font-black text-xl tracking-tight text-white">BrainBridge</span>
            <span className="text-[10px] font-bold uppercase tracking-wider ml-2 px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Campus Security & Auth Portal
            </span>
          </div>
        </div>

        {onCancelToLanding && (
          <button
            onClick={onCancelToLanding}
            className="text-xs font-semibold text-slate-400 hover:text-white transition"
          >
            &larr; Back to Landing Page
          </button>
        )}
      </div>

      {/* Main Container */}
      <div className="max-w-4xl mx-auto w-full my-auto py-8">
        {/* Title Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold mb-3">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>PRN Verified &bull; Row Level Security &bull; Supabase Auth Ready</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            {isAdminPortalMode
              ? 'Campus Administrator Control Center'
              : mode === 'login'
              ? 'Welcome Back to BrainBridge'
              : 'Student Registration with PRN Verification'}
          </h1>
          <p className="text-sm text-slate-400 mt-2 max-w-xl mx-auto">
            {isAdminPortalMode
              ? 'Restricted faculty access. Administrative privileges require institutional credentials and audit logging.'
              : mode === 'login'
              ? 'Select your student or certified tutor portal below to access your collaborative learning hub.'
              : 'Register your university student profile. PRN verification against the registrar roster ensures campus academic integrity.'}
          </p>
        </div>

        {/* Public Role Cards (Student & Tutor). Admin is isolated per Security Requirement #3 */}
        {!isAdminPortalMode && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 max-w-2xl mx-auto">
            {/* 1. Student Card */}
            <div
              onClick={() => handleSelectRole('learner')}
              className={`p-5 rounded-3xl border cursor-pointer transition relative flex flex-col justify-between ${
                selectedRole === 'learner'
                  ? 'bg-gradient-to-b from-blue-900/60 to-indigo-900/60 border-blue-400 ring-2 ring-blue-500/40 shadow-xl shadow-blue-500/10'
                  : 'bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xl">
                    🎓
                  </div>
                  {selectedRole === 'learner' && (
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-blue-500 text-white">
                      Selected
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-bold text-white mb-1">Student Portal</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Discover peer tutors, book study sessions, track XP quests, and master the Skill Tree with verified PRN credentials.
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                <span className="text-[11px] text-blue-300 font-semibold">
                  PRN Verification Required
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  Click to Sign In
                </span>
              </div>
            </div>

            {/* 2. Tutor Card */}
            <div
              onClick={() => handleSelectRole('tutor')}
              className={`p-5 rounded-3xl border cursor-pointer transition relative flex flex-col justify-between ${
                selectedRole === 'tutor'
                  ? 'bg-gradient-to-b from-emerald-900/60 to-teal-900/60 border-emerald-400 ring-2 ring-emerald-500/40 shadow-xl shadow-emerald-500/10'
                  : 'bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xl">
                    👨‍🏫
                  </div>
                  {selectedRole === 'tutor' && (
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500 text-white">
                      Selected
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-bold text-white mb-1">Tutor Portal</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Certified peer mentors publish open hours, approve booking requests, and build their verified teaching portfolio.
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                <span className="text-[11px] text-emerald-300 font-semibold">
                  Faculty Certified Tutors
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  Click to Sign In
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Auth Box */}
        <div className="max-w-xl mx-auto rounded-3xl bg-white/10 backdrop-blur-xl border border-white/15 p-6 sm:p-8 shadow-2xl">
          {/* Toggle Login vs Register (Students only; tutors must be verified by admin) */}
          {!isAdminPortalMode && (
            <div className="flex items-center p-1 bg-black/30 rounded-2xl mb-6">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setErrorMessage('');
                  setSuccessNotice(null);
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
                  mode === 'login'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Sign In ({selectedRole === 'learner' ? 'Student' : 'Tutor'})
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setErrorMessage('');
                  setSuccessNotice(null);
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
                  mode === 'register'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Register as Student with PRN
              </button>
            </div>
          )}

          {/* Admin Mode Header Alert */}
          {isAdminPortalMode && (
            <div className="mb-6 p-4 rounded-2xl bg-purple-950/60 border border-purple-500/40 text-purple-200">
              <div className="flex items-center gap-2.5 mb-1.5 font-bold text-sm text-purple-300">
                <ShieldAlert className="w-5 h-5 text-purple-400" />
                <span>Institutional Admin Access Gateway</span>
              </div>
              <p className="text-xs text-purple-300/80 leading-relaxed">
                Administrative roles cannot be self-assigned. Only pre-provisioned faculty credentials with database RLS clearance are authorized. All actions are logged to the platform audit trail.
              </p>
            </div>
          )}

          {/* Success Notification */}
          {successNotice && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2.5 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="mb-5 p-3 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-200 text-xs flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Form */}
          {mode === 'login' || isAdminPortalMode ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder={
                      isAdminPortalMode
                        ? 'admin@brainbridge.edu'
                        : selectedRole === 'learner'
                        ? 'Enter your student email'
                        : 'Enter your tutor email'
                    }
                    required
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 text-sm focus:border-indigo-400 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Password
                  </label>
                  {isAdminPortalMode && (
                    <span className="text-[11px] text-purple-300">
                      Default: admin123
                    </span>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 text-sm focus:border-indigo-400 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className={`w-full mt-2 py-3 rounded-xl font-bold text-sm shadow-xl transition flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 text-white ${
                  isAdminPortalMode
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-purple-600/30'
                    : selectedRole === 'tutor'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-600/30'
                    : 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-indigo-600/30'
                }`}
              >
                {isLoading ? (
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>
                      Sign In as{' '}
                      {isAdminPortalMode
                        ? 'Campus Admin'
                        : selectedRole === 'learner'
                        ? 'Student'
                        : 'Tutor'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {isAdminPortalMode && (
                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => handleSelectRole('learner')}
                    className="text-xs text-slate-400 hover:text-white underline transition"
                  >
                    Return to Student & Tutor Portal
                  </button>
                </div>
              )}
            </form>
          ) : (
            /* Student Registration with Mandatory PRN */
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
              <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-400/30 text-blue-200">
                <p className="font-bold flex items-center gap-1.5 text-blue-300">
                  <ShieldCheck className="w-4 h-4 text-blue-400" />
                  <span>Mandatory PRN Verification</span>
                </p>
                <p className="text-[11px] text-blue-300/80 mt-1 leading-relaxed">
                  Format rule: <code className="font-mono bg-blue-900/60 px-1 py-0.5 rounded">{collegeConfig.prnFormatName}</code>.
                  New student accounts enter a "Pending Verification" state until verified against the registrar database.
                </p>
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">
                  Full Student Name
                </label>
                <input
                  type="text"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Maya Ramirez"
                  required
                  className="w-full p-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 outline-none focus:border-indigo-400"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-slate-300 uppercase tracking-wider">
                    Email Address *
                  </label>
                  <span className="text-[10px] text-emerald-300 font-medium">
                    All email IDs accepted (Gmail, Outlook, College, etc.)
                  </span>
                </div>
                <input
                  type="email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="e.g. student@gmail.com, maya.r@campus.edu"
                  required
                  className="w-full p-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 outline-none focus:border-indigo-400"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-slate-300 uppercase tracking-wider">
                    Permanent Registration Number (PRN) *
                  </label>
                  <span className="text-[10px] text-indigo-300 font-mono">
                    Format: {collegeConfig.prnFormatName}
                  </span>
                </div>
                <input
                  type="text"
                  value={regPRN}
                  onChange={(e) => setRegPRN(e.target.value.toUpperCase())}
                  placeholder="PRN-2024-XXXX"
                  required
                  className="w-full p-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 outline-none focus:border-indigo-400 font-mono uppercase"
                />
              </div>

              {/* Password & Confirm Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Password *
                  </label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Min 6 characters"
                      required
                      className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 outline-none focus:border-indigo-400 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Confirm Password *
                  </label>
                  <div className="relative">
                    <input
                      type={showRegConfirmPassword ? 'text' : 'password'}
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      placeholder="Re-type password"
                      required
                      className={`w-full pl-3 pr-10 py-2.5 rounded-xl bg-white/10 border ${
                        regConfirmPassword && regPassword !== regConfirmPassword
                          ? 'border-rose-400 focus:border-rose-400'
                          : 'border-white/20 focus:border-indigo-400'
                      } text-white placeholder-slate-400 outline-none text-xs`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      {showRegConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Department Dropdown Menu */}
              <div>
                <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">
                  Department *
                </label>
                <select
                  value={regDepartment}
                  onChange={(e) => setRegDepartment(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-white/20 text-white outline-none focus:border-indigo-400 font-medium text-xs cursor-pointer"
                >
                  {DEPARTMENT_OPTIONS.map((dept) => (
                    <option key={dept} value={dept} className="bg-slate-900 text-white py-1">
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              {/* Academic Year and Semester Dropdowns */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Academic Year *
                  </label>
                  <select
                    value={regYear}
                    onChange={(e) => setRegYear(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-white/20 text-white outline-none focus:border-indigo-400 font-medium text-xs cursor-pointer"
                  >
                    {ACADEMIC_YEAR_OPTIONS.map((yr) => (
                      <option key={yr} value={yr} className="bg-slate-900 text-white py-1">
                        {yr}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">
                    Semester *
                  </label>
                  <select
                    value={regSemester}
                    onChange={(e) => setRegSemester(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-white/20 text-white outline-none focus:border-indigo-400 font-medium text-xs cursor-pointer"
                  >
                    {SEMESTER_OPTIONS.map((sem) => (
                      <option key={sem} value={sem} className="bg-slate-900 text-white py-1">
                        {sem}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 mt-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
              >
                {isLoading ? (
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Complete Registration</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

        </div>

        {/* Secure Admin Doorway Link (Requirement 3: Removed from public card grid) */}
        <div className="mt-6 text-center">
          {!isAdminPortalMode ? (
            <button
              onClick={() => handleSelectRole('admin')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-400 hover:text-purple-300 transition"
            >
              <Shield className="w-3.5 h-3.5 text-purple-400" />
              <span>Campus Administrator & Safety Officer Doorway</span>
            </button>
          ) : (
            <div className="inline-flex items-center gap-2 text-xs text-purple-300/70">
              <Lock className="w-3.5 h-3.5" />
              <span>Dedicated Faculty Security Clearance Zone</span>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="max-w-4xl mx-auto w-full text-center text-xs text-slate-500 py-2">
        <p>
          BrainBridge College Ecosystem &bull; Student PRN Verification &bull; PostgreSQL Row-Level Security
        </p>
      </div>
    </div>
  );
};

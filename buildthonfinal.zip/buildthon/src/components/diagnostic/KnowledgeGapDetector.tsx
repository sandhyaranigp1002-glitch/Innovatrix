import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Award,
  BookOpen,
  Brain,
  Calendar,
  CheckCircle2,
  Clock,
  Compass,
  FileQuestion,
  HelpCircle,
  Layers,
  Lightbulb,
  RotateCcw,
  Sparkles,
  TrendingUp,
  UserCheck,
  XCircle,
} from 'lucide-react';
import { DiagnosticQuiz, DiagnosticQuizResult, TutorProfile, UserProfile } from '../../types';
import { LocalStorageAdapter } from '../../services/storage';

interface KnowledgeGapDetectorProps {
  currentUser: UserProfile;
  quizzes: DiagnosticQuiz[];
  results: DiagnosticQuizResult[];
  allTutors: { user: UserProfile; profile: TutorProfile }[];
  onOpenBooking: (tutorId: string, subject?: string) => void;
  onNavigate: (page: string) => void;
}

export const KnowledgeGapDetector: React.FC<KnowledgeGapDetectorProps> = ({
  currentUser,
  quizzes,
  results,
  allTutors,
  onOpenBooking,
  onNavigate,
}) => {
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null);
  const [activeQuestionIndex, setActiveQuestionIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [latestResult, setLatestResult] = useState<DiagnosticQuizResult | null>(results[0] || null);
  const [activeTab, setActiveTab] = useState<'assessment' | 'history'>('assessment');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const activeQuiz = quizzes.find((q) => q.id === selectedQuizId);

  const handleSelectQuiz = (quizId: string) => {
    setSelectedQuizId(quizId);
    setActiveQuestionIndex(0);
    setSelectedAnswers({});
    setIsSubmitted(false);
  };

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIdx }));
  };

  const handleSubmitQuiz = () => {
    if (!activeQuiz) return;

    let correctCount = 0;
    const weakTopics: string[] = [];
    const strongTopics: string[] = [];

    activeQuiz.questions.forEach((q) => {
      const selected = selectedAnswers[q.id];
      if (selected === q.correctOptionIndex) {
        correctCount++;
        strongTopics.push(q.topic);
      } else {
        weakTopics.push(q.topic);
      }
    });

    const scorePct = Math.round((correctCount / activeQuiz.questions.length) * 100);

    // Build personalized practice plan
    const plan: string[] = [];
    if (weakTopics.length > 0) {
      plan.push(`Focus immediate review on: ${weakTopics.join(', ')}`);
      plan.push(`Book a 30-min targeted peer tutoring session focusing on ${weakTopics[0]}`);
      plan.push(`Solve 3 targeted conceptual problems on ${weakTopics.join(' and ')}`);
      plan.push(`Join a Micro Learning Circle discussing ${activeQuiz.subject}`);
    } else {
      plan.push(`Outstanding mastery! Consider applying to tutor ${activeQuiz.subject} to earn learning credits`);
      plan.push(`Tackle advanced algorithmic or architectural challenge problems in this subject`);
    }

    const savedResult = LocalStorageAdapter.saveDiagnosticResult({
      userId: currentUser.id,
      quizId: activeQuiz.id,
      subject: activeQuiz.subject,
      totalQuestions: activeQuiz.questions.length,
      correctAnswers: correctCount,
      scorePercentage: scorePct,
      weakTopics,
      strongTopics,
      recommendedTutorSubjects: [activeQuiz.subject],
      practicePlan: plan,
      isDemoSample: false,
    });

    setLatestResult(savedResult);
    setIsSubmitted(true);
  };

  // Find tutors that match the weak subjects
  const matchingTutors = allTutors.filter((t) =>
    latestResult?.recommendedTutorSubjects.some((sub) =>
      t.profile.subjects.some((s) => s.subject.toLowerCase().includes(sub.toLowerCase()))
    )
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 sm:p-8 text-white shadow-xl border border-indigo-900/40">
        <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-bold">
              <Brain className="w-3.5 h-3.5 text-cyan-400" />
              <span>Feature Three &bull; Knowledge Gap Detector</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Diagnostic Knowledge Gap Analyzer
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Take short, topic-targeted diagnostic checks to pinpoint your exact conceptual weak points.
              BrainBridge automatically maps your gaps to specialized peer mentors and builds a custom practice plan.
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => {
                setActiveTab('assessment');
                setSelectedQuizId(null);
                setIsSubmitted(false);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === 'assessment'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-white/10 hover:bg-white/20 text-slate-300'
              }`}
            >
              Take Assessment
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === 'history'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-white/10 hover:bg-white/20 text-slate-300'
              }`}
            >
              My Results History ({results.length})
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'assessment' ? (
        !selectedQuizId ? (
          /* Step 1: Select Diagnostic Subject */
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Choose a Subject to Diagnose</h3>
                <p className="text-xs text-slate-500">Each quiz takes 5-6 minutes and evaluates fundamental conceptual benchmarks.</p>
              </div>
              <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
                Earn +50 XP per diagnostic
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {quizzes.map((quiz) => (
                <div
                  key={quiz.id}
                  onClick={() => handleSelectQuiz(quiz.id)}
                  className="p-6 rounded-3xl bg-white border border-slate-200 hover:border-indigo-500 hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {quiz.difficulty}
                      </span>
                      <span className="text-xs font-medium text-slate-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {quiz.estimatedMinutes} mins
                      </span>
                    </div>

                    <h4 className="font-extrabold text-base text-slate-900 group-hover:text-indigo-600 transition">
                      {quiz.title}
                    </h4>
                    <p className="text-xs text-slate-500 leading-relaxed line-clamp-3">
                      {quiz.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-indigo-600">
                    <span>{quiz.questions.length} Diagnostic Questions</span>
                    <span className="flex items-center gap-1 group-hover:translate-x-1 transition">
                      Start Test &rarr;
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* Step 2: Interactive Quiz or Result View */
          <div className="space-y-6">
            {!isSubmitted ? (
              /* Quiz Taking Interface */
              <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                  <div>
                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                      {activeQuiz?.subject}
                    </span>
                    <h3 className="text-lg font-black text-slate-900">{activeQuiz?.title}</h3>
                  </div>

                  <button
                    onClick={() => setSelectedQuizId(null)}
                    className="text-xs font-bold text-slate-500 hover:text-slate-800 transition"
                  >
                    &larr; Back to Subjects
                  </button>
                </div>

                {/* Progress Indicators */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold text-slate-600">
                    <span>
                      Question {activeQuestionIndex + 1} of {activeQuiz?.questions.length}
                    </span>
                    <span>
                      {Math.round(((activeQuestionIndex + 1) / (activeQuiz?.questions.length || 1)) * 100)}% Complete
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                      style={{
                        width: `${((activeQuestionIndex + 1) / (activeQuiz?.questions.length || 1)) * 100}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Current Question */}
                {activeQuiz && (
                  <div className="space-y-5 pt-2">
                    {(() => {
                      const q = activeQuiz.questions[activeQuestionIndex];
                      const selected = selectedAnswers[q.id];
                      return (
                        <div key={q.id} className="space-y-4">
                          <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-1">
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                              Target Topic: {q.topic}
                            </span>
                            <h4 className="font-extrabold text-base text-slate-900 pt-1">
                              {q.question}
                            </h4>
                          </div>

                          <div className="space-y-2.5">
                            {q.options.map((opt, optIdx) => (
                              <div
                                key={optIdx}
                                onClick={() => handleSelectOption(q.id, optIdx)}
                                className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between text-xs sm:text-sm font-semibold ${
                                  selected === optIdx
                                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
                                    : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
                                }`}
                              >
                                <div className="flex items-center gap-3">
                                  <span
                                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                                      selected === optIdx
                                        ? 'bg-white/20 text-white'
                                        : 'bg-slate-100 text-slate-600'
                                    }`}
                                  >
                                    {String.fromCharCode(65 + optIdx)}
                                  </span>
                                  <span>{opt}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}

                {/* Bottom Navigation */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <button
                    disabled={activeQuestionIndex === 0}
                    onClick={() => setActiveQuestionIndex((i) => Math.max(0, i - 1))}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40"
                  >
                    Previous
                  </button>

                  {activeQuestionIndex < (activeQuiz?.questions.length || 0) - 1 ? (
                    <button
                      disabled={selectedAnswers[activeQuiz?.questions[activeQuestionIndex].id || ''] === undefined}
                      onClick={() => setActiveQuestionIndex((i) => i + 1)}
                      className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 shadow-md shadow-indigo-600/20 disabled:opacity-40 transition active:scale-95"
                    >
                      Next Question &rarr;
                    </button>
                  ) : (
                    <button
                      disabled={Object.keys(selectedAnswers).length < (activeQuiz?.questions.length || 0)}
                      onClick={handleSubmitQuiz}
                      className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition active:scale-95"
                    >
                      Analyze My Knowledge Gaps &rarr;
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* Diagnostic Results View */
              latestResult && (
                <div className="space-y-6">
                  {/* Score Summary Card */}
                  <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold mb-2">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Assessment Complete &bull; Verified Analysis</span>
                        </div>
                        <h2 className="text-2xl font-black text-slate-900">
                          {latestResult.subject} Diagnostic Report
                        </h2>
                        <p className="text-xs text-slate-500 mt-1">
                          Evaluated on {new Date(latestResult.completedAt).toLocaleDateString()} &bull; +50 XP &amp; +2 Learning Credits Awarded
                        </p>
                      </div>

                      <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                        <div className="text-right">
                          <span className="text-3xl font-black text-slate-900">
                            {latestResult.scorePercentage}%
                          </span>
                          <p className="text-[11px] text-slate-500">
                            {latestResult.correctAnswers} / {latestResult.totalQuestions} Correct
                          </p>
                        </div>
                        <div
                          className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg ${
                            latestResult.scorePercentage >= 80
                              ? 'bg-emerald-100 text-emerald-800'
                              : latestResult.scorePercentage >= 50
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {latestResult.scorePercentage >= 80 ? 'A' : latestResult.scorePercentage >= 50 ? 'B' : 'C'}
                        </div>
                      </div>
                    </div>

                    {/* Knowledge Gaps vs Strengths Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Weak Topics */}
                      <div className="p-5 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-3">
                        <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                          <AlertCircle className="w-4 h-4 text-amber-600" />
                          <span>Identified Knowledge Gaps ({latestResult.weakTopics.length})</span>
                        </div>
                        {latestResult.weakTopics.length === 0 ? (
                          <p className="text-xs text-emerald-700 font-medium">
                            🎉 No weak gaps detected! Excellent conceptual clarity.
                          </p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5">
                            {latestResult.weakTopics.map((topic, i) => (
                              <span
                                key={i}
                                className="px-3 py-1 rounded-xl bg-white border border-amber-300 text-amber-900 font-bold text-xs shadow-sm"
                              >
                                ⚠️ {topic}
                              </span>
                            ))}
                          </div>
                        )}
                        <p className="text-[11px] text-amber-800 leading-relaxed">
                          These concepts require targeted peer review before upcoming midterms and examinations.
                        </p>
                      </div>

                      {/* Strong Topics */}
                      <div className="p-5 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 space-y-3">
                        <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Demonstrated Strengths ({latestResult.strongTopics.length})</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {latestResult.strongTopics.map((topic, i) => (
                            <span
                              key={i}
                              className="px-3 py-1 rounded-xl bg-white border border-emerald-300 text-emerald-900 font-bold text-xs shadow-sm"
                            >
                              ✓ {topic}
                            </span>
                          ))}
                        </div>
                        <p className="text-[11px] text-emerald-800 leading-relaxed">
                          Solid foundations demonstrated. You can help peers master these topics in study circles!
                        </p>
                      </div>
                    </div>

                    {/* Actionable Practice Plan */}
                    <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                      <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                        <Lightbulb className="w-4 h-4 text-amber-500" />
                        <span>Personalized Practice &amp; Remediation Plan</span>
                      </div>
                      <ol className="space-y-2 text-xs text-slate-700 list-decimal list-inside leading-relaxed">
                        {latestResult.practicePlan.map((step, idx) => (
                          <li key={idx} className="font-medium">
                            {step}
                          </li>
                        ))}
                      </ol>
                    </div>

                    {/* Explanations Accordion */}
                    <div className="space-y-3 pt-2">
                      <h4 className="font-extrabold text-sm text-slate-900">
                        Detailed Question Review &amp; Explanations
                      </h4>
                      <div className="space-y-2.5">
                        {activeQuiz?.questions.map((q, idx) => {
                          const userAns = selectedAnswers[q.id];
                          const isCorrect = userAns === q.correctOptionIndex;
                          return (
                            <div
                              key={q.id}
                              className={`p-4 rounded-2xl border text-xs space-y-2 ${
                                isCorrect
                                  ? 'bg-emerald-50/40 border-emerald-200'
                                  : 'bg-rose-50/40 border-rose-200'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <span className="font-bold text-slate-800">
                                  {idx + 1}. {q.question}
                                </span>
                                {isCorrect ? (
                                  <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">
                                    Correct
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-black uppercase text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full shrink-0">
                                    Gap Identified
                                  </span>
                                )}
                              </div>
                              <p className="text-slate-600">
                                <strong>Your Answer:</strong> {q.options[userAns] || 'Not answered'}
                              </p>
                              {!isCorrect && (
                                <p className="text-emerald-700">
                                  <strong>Correct Answer:</strong> {q.options[q.correctOptionIndex]}
                                </p>
                              )}
                              <p className="text-slate-500 text-[11px] italic bg-white/70 p-2 rounded-xl border border-slate-100">
                                💡 {q.explanation}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Matching Tutors Recommendation Card */}
                  <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-indigo-900 to-violet-950 text-white shadow-xl space-y-5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-cyan-300 text-xs font-bold mb-1">
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Smart Tutor Match for Your Gaps</span>
                        </div>
                        <h3 className="text-xl font-black">
                          Verified Mentors Specializing in {latestResult.subject}
                        </h3>
                        <p className="text-xs text-indigo-200 mt-1">
                          Book a 1-on-1 peer session using your learning credits to resolve gaps before your exam.
                        </p>
                      </div>

                      <button
                        onClick={() => setSelectedQuizId(null)}
                        className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center gap-1.5 self-start"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Retake Diagnostic</span>
                      </button>
                    </div>

                    {matchingTutors.length === 0 ? (
                      <div className="p-6 text-center bg-white/5 rounded-2xl border border-white/10">
                        <Compass className="w-8 h-8 mx-auto text-indigo-300 mb-2" />
                        <p className="text-xs font-semibold text-white">No active mentors found for this specific gap</p>
                        <p className="text-[11px] text-indigo-200 mt-0.5">Explore the Tutor Directory or request a study circle.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {matchingTutors.map(({ user, profile }) => (
                          <div
                            key={user.id}
                            className="p-5 rounded-2xl bg-white text-slate-900 shadow-md space-y-3 flex flex-col justify-between"
                          >
                            <div className="space-y-2">
                              <div className="flex items-center gap-3">
                                <img
                                  src={user.avatar}
                                  alt={user.name}
                                  className="w-10 h-10 rounded-xl object-cover border border-slate-200"
                                />
                                <div>
                                  <h4 className="font-extrabold text-sm">{user.name}</h4>
                                  <p className="text-[11px] text-indigo-600 font-semibold">{user.department}</p>
                                </div>
                              </div>
                              <p className="text-xs text-slate-500 line-clamp-2">{user.bio}</p>
                            </div>

                            <button
                              onClick={() => onOpenBooking(user.id, latestResult.subject)}
                              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
                            >
                              Book Gap Resolution &rarr;
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )
            )}
          </div>
        )
      ) : (
        /* Results History View */
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900">Your Diagnostic History</h3>
          {results.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <FileQuestion className="w-12 h-12 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-semibold">No diagnostic tests taken yet</p>
              <p className="text-xs text-slate-500 mt-1">Take your first subject check above to identify knowledge gaps!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {results.map((res) => (
                <div
                  key={res.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-slate-900">{res.subject}</span>
                      {res.isDemoSample && (
                        <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                          Sample Demo Data
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500">
                      Completed on {new Date(res.completedAt).toLocaleDateString()} &bull;{' '}
                      {res.weakTopics.length > 0 ? `${res.weakTopics.length} gaps identified` : 'Zero gaps detected'}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <span
                      className={`text-sm font-black px-3 py-1 rounded-xl ${
                        res.scorePercentage >= 80
                          ? 'bg-emerald-100 text-emerald-800'
                          : res.scorePercentage >= 50
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {res.scorePercentage}%
                    </span>
                    <button
                      onClick={() => {
                        setLatestResult(res);
                        setActiveTab('assessment');
                        setSelectedQuizId(res.quizId);
                        setIsSubmitted(true);
                      }}
                      className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 transition"
                    >
                      View Report
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import {
  AlertCircle,
  Award,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  ExternalLink,
  Flame,
  GraduationCap,
  HeartHandshake,
  MapPin,
  MessageSquare,
  Plus,
  Sparkles,
  Star,
  Trash2,
  User,
  Users2,
  Video,
  X,
  Zap,
} from 'lucide-react';
import {
  AvailabilitySlot,
  SessionRequest,
  SessionReview,
  TutorProfile,
  UserProfile,
} from '../../types';
import { getXPProgress } from '../../services/gamification';

interface TutorDashboardProps {
  currentUser: UserProfile;
  tutorProfile?: TutorProfile;
  sessions: SessionRequest[];
  allUsers: UserProfile[];
  slots: AvailabilitySlot[];
  reviews: SessionReview[];
  onAcceptSession: (sessionId: string) => void;
  onDeclineSession: (sessionId: string) => void;
  onAddSlot: (slot: Omit<AvailabilitySlot, 'id'>) => void;
  onDeleteSlot: (slotId: string) => void;
  onOpenSessionRoom: (session: SessionRequest) => void;
  onNavigate: (page: string) => void;
}

export const TutorDashboard: React.FC<TutorDashboardProps> = ({
  currentUser,
  tutorProfile,
  sessions,
  allUsers,
  slots,
  reviews,
  onAcceptSession,
  onDeclineSession,
  onAddSlot,
  onDeleteSlot,
  onOpenSessionRoom,
  onNavigate,
}) => {
  const xpProg = getXPProgress(currentUser.xp);

  // Quick slot creator state
  const [quickDay, setQuickDay] = useState('Thursday');
  const [quickDate, setQuickDate] = useState('2026-10-22');
  const [quickStart, setQuickStart] = useState('15:00');
  const [quickEnd, setQuickEnd] = useState('16:00');
  const [quickMode, setQuickMode] = useState<'online' | 'in_person'>('online');
  const [quickLocation, setQuickLocation] = useState('https://meet.google.com/brainbridge-mentor-room');
  const [slotCreatedFeedback, setSlotCreatedFeedback] = useState(false);

  // Filter my sessions as tutor
  const myTutoringSessions = sessions.filter((s) => s.tutorId === currentUser.id);
  const pendingRequests = myTutoringSessions.filter((s) => s.status === 'pending');
  const upcomingConfirmed = myTutoringSessions.filter((s) => s.status === 'accepted');
  const completedSessions = myTutoringSessions.filter((s) => s.status === 'completed');

  // Filter my slots
  const mySlots = slots.filter((s) => s.tutorId === currentUser.id);
  const openSlots = mySlots.filter((s) => !s.isBooked);

  // Reviews for this tutor
  const myReviews = reviews.filter((r) => r.tutorId === currentUser.id);

  // Quick add slot handler
  const handleQuickAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    onAddSlot({
      tutorId: currentUser.id,
      dayOfWeek: quickDay,
      date: quickDate,
      startTime: quickStart,
      endTime: quickEnd,
      mode: quickMode,
      locationOrLink: quickLocation,
      isBooked: false,
    });
    setSlotCreatedFeedback(true);
    setTimeout(() => setSlotCreatedFeedback(false), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-teal-900 to-indigo-950 p-6 sm:p-8 text-white shadow-xl shadow-emerald-950/20">
        <div className="absolute -top-12 -right-12 w-64 h-64 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-emerald-200 text-xs font-bold">
              <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
              <span>Campus Mentor Hub &bull; Active TA Status</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Welcome to your Tutor Studio, {currentUser.name.split(' ')[0]}! 👨‍🏫
            </h1>
            <p className="text-sm text-emerald-100 max-w-xl leading-relaxed">
              {pendingRequests.length > 0
                ? `You have ${pendingRequests.length} pending student session request${pendingRequests.length > 1 ? 's' : ''} awaiting your review. Accept to confirm time slots.`
                : 'All caught up! Your students rate your clarity at ★' + (tutorProfile?.rating.toFixed(1) || '5.0') + '. Publish additional hours to help more peers.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('availability')}
              className="px-5 py-2.5 rounded-xl bg-white text-emerald-950 font-bold text-xs sm:text-sm hover:bg-emerald-50 shadow-md transition active:scale-95"
            >
              Availability &amp; Subjects
            </button>
            <button
              onClick={() => onNavigate('sessions')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold text-xs sm:text-sm backdrop-blur-md transition"
            >
              All Tutoring Bookings
            </button>
          </div>
        </div>
      </div>

      {/* Tutor Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Rating */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Student Rating
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900">
                {tutorProfile?.rating.toFixed(1) || '5.0'}
              </span>
              <span className="text-xs font-medium text-slate-500">
                / 5.0 ({tutorProfile?.reviewCount || myReviews.length} reviews)
              </span>
            </div>
            <p className="text-[11px] text-emerald-600 font-semibold mt-1">
              Top 5% University Peer Mentor
            </p>
          </div>
        </div>

        {/* Sessions Completed */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Sessions Taught
            </span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900">
                {completedSessions.length}
              </span>
              <span className="text-xs font-semibold text-indigo-600">
                +{completedSessions.length * 150} XP earned
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              {upcomingConfirmed.length} upcoming scheduled sessions
            </p>
          </div>
        </div>

        {/* Open Slots */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Open Slots
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900">
                {openSlots.length}
              </span>
              <span className="text-xs font-medium text-slate-500">
                of {mySlots.length} total slots
              </span>
            </div>
            <p className="text-[11px] text-emerald-700 font-semibold mt-1">
              Guaranteed conflict-free booking
            </p>
          </div>
        </div>

        {/* Tutor Impact Score */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Impact Score
            </span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
              <HeartHandshake className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900">
                {currentUser.impactScore}
              </span>
              <span className="text-xs font-semibold text-teal-700">Level {currentUser.level}</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              {currentUser.streakDays}-day active streak 🔥
            </p>
          </div>
        </div>
      </div>

      {/* Urgent Section: Incoming Student Session Requests */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900">
                Incoming Student Session Requests
              </h3>
              {pendingRequests.length > 0 && (
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 animate-pulse">
                  {pendingRequests.length} Action Needed
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Review learning objectives and accept or decline requests to confirm the calendar slot
            </p>
          </div>
        </div>

        {pendingRequests.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-slate-500 text-xs">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
            <p className="font-semibold text-slate-800">No pending session requests</p>
            <p className="text-slate-400 mt-0.5">
              You are completely caught up! New student requests will appear here immediately.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {pendingRequests.map((req) => {
              const student = allUsers.find((u) => u.id === req.learnerId);
              return (
                <div
                  key={req.id}
                  className="p-5 rounded-2xl border border-amber-200 bg-amber-50/40 hover:bg-amber-50/70 transition space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-amber-200/60">
                    <div className="flex items-center gap-3">
                      <img
                        src={student?.avatar}
                        alt={student?.name}
                        className="w-12 h-12 rounded-2xl object-cover border border-amber-300"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-slate-900 text-sm">
                            {req.subject} Tutoring Request
                          </h4>
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-200 text-amber-900">
                            Pending
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Student: <strong>{student?.name || 'Alex Chen'}</strong> ({student?.department} &bull; {student?.academicYear})
                        </p>
                      </div>
                    </div>

                    <div className="text-xs text-slate-600 sm:text-right space-y-0.5">
                      <div className="font-semibold text-slate-900 flex items-center sm:justify-end gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{req.date} &bull; {req.startTime} - {req.endTime}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center sm:justify-end gap-1">
                        {req.mode === 'online' ? <Video className="w-3 h-3 text-indigo-500" /> : <MapPin className="w-3 h-3 text-rose-500" />}
                        <span className="truncate max-w-xs">{req.locationOrLink}</span>
                      </div>
                    </div>
                  </div>

                  {/* Stated Learning Goal */}
                  <div className="p-3 bg-white rounded-xl border border-amber-200/80 text-xs">
                    <span className="font-bold text-amber-900">Student's Learning Goal: </span>
                    <span className="text-slate-700 italic">"{req.learningGoal}"</span>
                  </div>

                  {/* Accept / Decline actions */}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => onDeclineSession(req.id)}
                      className="px-4 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs transition flex items-center gap-1.5"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Decline</span>
                    </button>
                    <button
                      onClick={() => onAcceptSession(req.id)}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition flex items-center gap-1.5 active:scale-95"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Accept Session &amp; Lock Slot</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Grid: Upcoming Sessions & Quick Slot Publisher */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Confirmed Sessions (2 cols) */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Upcoming Confirmed Sessions ({upcomingConfirmed.length})
            </h3>
            <button
              onClick={() => onNavigate('sessions')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
            >
              View Full History &rarr;
            </button>
          </div>

          {upcomingConfirmed.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No confirmed upcoming sessions right now. Open slots are published below for students to book.
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingConfirmed.map((sess) => {
                const student = allUsers.find((u) => u.id === sess.learnerId);
                return (
                  <div
                    key={sess.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-slate-900 text-sm">
                          {sess.subject}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                          Confirmed
                        </span>
                      </div>
                      <p className="text-slate-600 mt-0.5">
                        With Student: <strong>{student?.name}</strong>
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-indigo-600" />
                        <span>{sess.date} &bull; {sess.startTime} - {sess.endTime}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {sess.mode === 'online' && (
                        <a
                          href={sess.locationOrLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition"
                        >
                          <Video className="w-3.5 h-3.5" />
                          <span>Google Meet</span>
                        </a>
                      )}
                      <button
                        onClick={() => onOpenSessionRoom(sess)}
                        className="px-3.5 py-1.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-bold text-xs transition"
                      >
                        Room Details &rarr;
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Quick Slot Publishing Widget (1 col) */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-emerald-600" />
              Quick Slot Publisher
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Open a new study window instantly
            </p>
          </div>

          {slotCreatedFeedback && (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Available slot published successfully!</span>
            </div>
          )}

          <form onSubmit={handleQuickAddSlot} className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">
                Day &amp; Date
              </label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={quickDay}
                  onChange={(e) => setQuickDay(e.target.value)}
                  className="p-2 rounded-xl border border-slate-300 bg-white font-medium outline-none"
                >
                  {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
                <input
                  type="date"
                  value={quickDate}
                  onChange={(e) => setQuickDate(e.target.value)}
                  className="p-2 rounded-xl border border-slate-300 font-medium outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Start
                </label>
                <input
                  type="time"
                  value={quickStart}
                  onChange={(e) => setQuickStart(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-300 font-medium outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">
                  End
                </label>
                <input
                  type="time"
                  value={quickEnd}
                  onChange={(e) => setQuickEnd(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-300 font-medium outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">
                Meeting Format
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setQuickMode('online');
                    setQuickLocation('https://meet.google.com/brainbridge-mentor-room');
                  }}
                  className={`py-1.5 rounded-lg border font-bold text-[11px] transition ${
                    quickMode === 'online' ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'border-slate-200 text-slate-600'
                  }`}
                >
                  Online Meet
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setQuickMode('in_person');
                    setQuickLocation('CS Building Room 304');
                  }}
                  className={`py-1.5 rounded-lg border font-bold text-[11px] transition ${
                    quickMode === 'in_person' ? 'bg-emerald-50 border-emerald-500 text-emerald-700' : 'border-slate-200 text-slate-600'
                  }`}
                >
                  On-Campus
                </button>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-600 uppercase tracking-wider mb-1">
                Link or Room Location
              </label>
              <input
                type="text"
                value={quickLocation}
                onChange={(e) => setQuickLocation(e.target.value)}
                required
                className="w-full p-2 rounded-xl border border-slate-300 font-medium outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold shadow-md shadow-emerald-600/20 transition active:scale-95"
            >
              Publish Available Slot
            </button>
          </form>
        </div>
      </div>

      {/* Student Reviews & Badges Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Student Feedback */}
        <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
              Verified Student Reviews
            </h3>
            <span className="text-xs font-semibold text-slate-400">
              {myReviews.length} total reviews
            </span>
          </div>

          {myReviews.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">
              No reviews yet. Completed sessions will show student feedback here.
            </p>
          ) : (
            <div className="space-y-3">
              {myReviews.map((rev) => (
                <div key={rev.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-amber-500 font-bold">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3.5 h-3.5 ${
                            i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      ))}
                      <span className="text-slate-700 ml-1">★{rev.rating}.0</span>
                    </div>
                    <span className="text-[10px] text-slate-400">
                      {new Date(rev.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-slate-700 italic">"{rev.feedback}"</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Tutor Badges & Credentials */}
        <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" />
              Tutor Badges &amp; Credentials
            </h3>
            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
              {currentUser.badges.length} Badges Unlocked
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
                <GraduationCap className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-indigo-950">Knowledge Sharer</p>
                <p className="text-[10px] text-indigo-700">Taught 5+ sessions</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50/60 border border-amber-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold">
                <HeartHandshake className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-amber-950">Community Hero</p>
                <p className="text-[10px] text-amber-700">Guided multiple peers</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                <Star className="w-4 h-4 fill-white" />
              </div>
              <div>
                <p className="font-bold text-emerald-950">Perfect Partner</p>
                <p className="text-[10px] text-emerald-700">High peer ratings</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-purple-50/60 border border-purple-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold">
                <Zap className="w-4 h-4 fill-white" />
              </div>
              <div>
                <p className="font-bold text-purple-950">Mentor Rank</p>
                <p className="text-[10px] text-purple-700">Level 4 Verified</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('availability')}
            className="w-full py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl transition"
          >
            Manage Teaching Subjects &amp; Campus Hours &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};

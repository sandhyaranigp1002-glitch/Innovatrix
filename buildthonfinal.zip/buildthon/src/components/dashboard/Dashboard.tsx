import React, { useState, useEffect } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  ArrowRight,
  Award,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Compass,
  Flame,
  GitBranch,
  GraduationCap,
  HeartHandshake,
  LogOut,
  Mail,
  MapPin,
  Play,
  ShieldCheck,
  Sparkles,
  Star,
  Trophy,
  User,
  Users2,
  Video,
  Zap,
} from 'lucide-react';
import {
  AvailabilitySlot,
  DailyQuest,
  InAppNotification,
  SessionRequest,
  TutorProfile,
  UserProfile,
} from '../../types';
import { ALL_BADGES, getXPProgress } from '../../services/gamification';
import { api, CollegeInfo, TutorRecord } from '../../services/api';
import { OnlineLectureSessionsHub } from '../sessions/OnlineLectureSessionsHub';
import { RecordedLecturesHub } from '../lectures/RecordedLecturesHub';

interface DashboardProps {
  currentUser: UserProfile;
  upcomingSessions: SessionRequest[];
  recommendedTutors: { user: UserProfile; profile: TutorProfile; matchReasons: string[] }[];
  dailyQuests: DailyQuest[];
  onClaimQuest: (questId: string) => void;
  onNavigate: (page: string) => void;
  onOpenSession: (session: SessionRequest) => void;
  onBookTutor: (tutorId: string) => void;
  leaderboardTop: { rank: number; name: string; avatar: string; xp: number; levelTitle: string }[];
  onLogout?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentUser,
  upcomingSessions,
  recommendedTutors,
  dailyQuests,
  onClaimQuest,
  onNavigate,
  onOpenSession,
  onBookTutor,
  leaderboardTop,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'sessions' | 'recordings'>('overview');
  const [collegeInfo, setCollegeInfo] = useState<CollegeInfo | null>(null);
  const [tutors, setTutors] = useState<TutorRecord[]>([]);
  const xpProg = getXPProgress(currentUser.xp);

  useEffect(() => {
    // Load College Info (Principal) and Tutors from SQLite database
    const loadCollegeData = async () => {
      try {
        const info = await api.getCollegeInfo();
        setCollegeInfo(info);
      } catch (e) {
        // Fallback default
        setCollegeInfo({
          id: 'college_main',
          institution_name: 'BrainBridge College of Engineering & Technology',
          principal_designation: 'Principal',
          principal_name: 'Dr. Suhas Sapate Sir',
        });
      }

      try {
        const tuts = await api.getTutors();
        setTutors(tuts);
      } catch (e) {
        // Fallback list
        setTutors([
          { id: '1', name: 'Sandhyarani Patil', subject: 'DSA', email: 'sandhyarani.patil@brainbridge.edu', department: 'Computer Science and Engineering (CSE)', experience_years: 4, rating: 4.9, is_active: 1 },
          { id: '2', name: 'Rutuja Gaikwad', subject: 'Java', email: 'rutuja.gaikwad@brainbridge.edu', department: 'Computer Science and Engineering (CSE)', experience_years: 4, rating: 4.9, is_active: 1 },
          { id: '3', name: 'Vivek Utturkar', subject: 'Python', email: 'vivek.utturkar@brainbridge.edu', department: 'Information Technology (IT)', experience_years: 4, rating: 4.9, is_active: 1 },
          { id: '4', name: 'Rohan Patil', subject: 'DBMS', email: 'rohan.patil@brainbridge.edu', department: 'Computer Science and Engineering (CSE)', experience_years: 4, rating: 4.9, is_active: 1 },
        ]);
      }
    };
    loadCollegeData();
  }, []);

  const nextSession = upcomingSessions.find(
    (s) => s.status === 'accepted' || s.status === 'pending'
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* 1. Verified Student Profile Identity Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-7 text-white shadow-xl border border-indigo-900/40 relative overflow-hidden">
        <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-64 h-64 rounded-full bg-violet-600/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Student Info Details */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <div className="relative">
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80'}
                alt={currentUser.name}
                className="w-20 h-20 rounded-2xl object-cover border-2 border-indigo-400/40 shadow-lg"
              />
              <span className="absolute -bottom-1 -right-1 p-1 bg-emerald-500 rounded-full border-2 border-slate-900" title="Active Verified Student">
                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {currentUser.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-[11px] font-bold">
                  {currentUser.role === 'admin' ? 'Campus Administrator' : currentUser.role === 'tutor' ? 'Certified Tutor' : 'Registered Student'}
                </span>
              </div>

              {/* Student Metadata Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-1 text-xs text-indigo-200/90 pt-1">
                <p className="flex items-center gap-1.5 font-medium">
                  <span className="text-slate-400">Student ID / PRN:</span>
                  <code className="font-mono bg-white/10 px-1.5 py-0.5 rounded text-white font-bold tracking-wider">
                    {currentUser.prn || 'PRN-2024-STUDENT'}
                  </code>
                </p>

                <p className="flex items-center gap-1.5 truncate">
                  <Mail className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="text-white font-medium truncate">{currentUser.email}</span>
                </p>

                <p className="flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="text-white font-medium">{currentUser.department || 'Computer Science and Engineering (CSE)'}</span>
                </p>

                <p className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="text-white font-medium">{currentUser.academicYear || 'First Year'}</span>
                </p>

                <p className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="text-white font-medium">{currentUser.semester || 'Semester 1'}</span>
                </p>
              </div>
            </div>
          </div>

          {/* Quick Actions & Working Logout Button */}
          <div className="flex flex-wrap items-center gap-3 self-end lg:self-center">
            {onLogout && (
              <button
                onClick={onLogout}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-rose-600/90 border border-white/20 text-white font-bold text-xs transition flex items-center gap-2 active:scale-95 shadow-sm"
                title="Sign out of student account"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            )}
            <button
              onClick={() => setActiveTab('recordings')}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition shadow-md shadow-indigo-600/30 flex items-center gap-2 active:scale-95"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Watch Lectures</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Institutional Leadership & Principal Information */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-700 to-indigo-900 text-white flex items-center justify-center font-serif text-xl font-bold shadow-md shadow-indigo-900/20 shrink-0">
            🏛️
          </div>
          <div>
            <div className="flex items-center gap-2 text-indigo-600 font-bold text-[11px] uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>College Administration &amp; Leadership</span>
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                {collegeInfo?.principal_name || 'Dr. Suhas Sapate Sir'}
              </h3>
              <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-xs">
                {collegeInfo?.principal_designation || 'Principal'}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {collegeInfo?.institution_name || 'BrainBridge College of Engineering & Technology'}
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-500 text-right hidden md:block">
          <span className="font-semibold text-slate-700">Official Campus Portal</span>
          <p className="text-[11px] text-slate-400">Accredited Peer Learning &amp; Course Management</p>
        </div>
      </div>

      {/* 3. Assigned Faculty Tutors & Subject Mapping */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider mb-1">
              <GraduationCap className="w-4 h-4" />
              <span>Course Faculty &bull; Official Tutor Roster</span>
            </div>
            <h3 className="text-lg font-black text-slate-900">
              Assigned Tutors &amp; Subject Specialists
            </h3>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700">
            4 Core Engineering Subjects
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {tutors.map((tutor, idx) => (
            <div
              key={tutor.id}
              className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-indigo-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-slate-200/80 text-slate-700">
                    Sr. No. {idx + 1}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-extrabold">
                    {tutor.subject}
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 text-sm">{tutor.name}</h4>
                <p className="text-xs text-slate-500 mt-0.5">{tutor.department}</p>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">Rating: ⭐ {tutor.rating || '4.9'}</span>
                <button
                  onClick={() => {
                    setActiveTab('recordings');
                  }}
                  className="font-bold text-indigo-600 hover:text-indigo-800 hover:underline"
                >
                  View Lectures &rarr;
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Navigation Tabs: Overview vs Live Lecture Sessions vs Recorded Lectures */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
            activeTab === 'overview'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Student Dashboard Overview
        </button>
        <button
          onClick={() => setActiveTab('sessions')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
            activeTab === 'sessions'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>Online Lecture Sessions</span>
        </button>
        <button
          onClick={() => setActiveTab('recordings')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 ${
            activeTab === 'recordings'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Recorded Lectures</span>
        </button>
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Top Stats Overview Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Card 1: Level Progress */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Level &amp; Rank
                </span>
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-xs">
                  L{currentUser.level}
                </div>
              </div>
              <div>
                <div className="flex items-baseline justify-between mb-1.5">
                  <span className="text-xl font-extrabold text-slate-900">
                    {currentUser.levelTitle}
                  </span>
                  <span className="text-xs font-semibold text-indigo-600">
                    {currentUser.xp} XP
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${xpProg.progressPercent}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5">
                  Target: {xpProg.nextLevelTarget} XP to Next Rank
                </p>
              </div>
            </div>

            {/* Card 2: Learning Streak */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Daily Streak
                </span>
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
                </div>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-slate-900">
                    {currentUser.streakDays}
                  </span>
                  <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                    Active Streak 🔥
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Personal best: <strong>{currentUser.bestStreak} days</strong> in a row
                </p>
              </div>
            </div>

            {/* Card 3: Assigned Subjects */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Available Subjects
                </span>
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <BookOpen className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-slate-900">4</span>
                  <span className="text-xs font-semibold text-emerald-600">DSA, Java, Python, DBMS</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  All 4 faculty specialists actively teaching
                </p>
              </div>
            </div>

            {/* Card 4: Upcoming Sessions */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Live Lectures
                </span>
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Video className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-slate-900">
                    {upcomingSessions.length || 3}
                  </span>
                  <span className="text-xs font-medium text-slate-500">Scheduled</span>
                </div>
                <button
                  onClick={() => setActiveTab('sessions')}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 mt-1 flex items-center gap-1"
                >
                  <span>Launch Live Classroom</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Quick Preview of Upcoming Online Sessions */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Video className="w-4 h-4 text-indigo-600" />
                  Upcoming Online Lecture Sessions
                </h3>
                <p className="text-xs text-slate-500">
                  Connect live with tutors via Google Meet &bull; Auto-generated Session ID tracking
                </p>
              </div>
              <button
                onClick={() => setActiveTab('sessions')}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
              >
                View All Sessions &rarr;
              </button>
            </div>

            <OnlineLectureSessionsHub
              userDepartment={currentUser.department}
              userAcademicYear={currentUser.academicYear}
            />
          </div>

          {/* Daily Quests & Challenges */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  Today's Daily Quests
                </h3>
                <p className="text-xs text-slate-500">
                  Complete daily study objectives to earn verified XP rewards
                </p>
              </div>
              <button
                onClick={() => onNavigate('quest')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                View Quests &rarr;
              </button>
            </div>

            <div className="space-y-3">
              {dailyQuests.slice(0, 3).map((quest) => (
                <div
                  key={quest.id}
                  className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    quest.isClaimed
                      ? 'bg-slate-50/80 border-slate-200 opacity-70'
                      : quest.isCompleted
                      ? 'bg-amber-50/50 border-amber-200'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">{quest.title}</span>
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                        +{quest.xpReward} XP
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">{quest.description}</p>
                  </div>

                  <div>
                    {quest.isClaimed ? (
                      <span className="text-xs font-semibold text-slate-400">Claimed</span>
                    ) : quest.isCompleted ? (
                      <button
                        onClick={() => onClaimQuest(quest.id)}
                        className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs"
                      >
                        Claim Reward
                      </button>
                    ) : (
                      <span className="text-xs font-medium text-slate-400">In Progress</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Online Lecture Sessions Hub */}
      {activeTab === 'sessions' && (
        <div className="space-y-4">
          <OnlineLectureSessionsHub
            userDepartment={currentUser.department}
            userAcademicYear={currentUser.academicYear}
            canManage={currentUser.role === 'admin' || currentUser.role === 'tutor'}
          />
        </div>
      )}

      {/* Tab 3: Recorded Lectures Hub */}
      {activeTab === 'recordings' && (
        <div className="space-y-4">
          <RecordedLecturesHub
            userDepartment={currentUser.department}
            userAcademicYear={currentUser.academicYear}
            canManage={currentUser.role === 'admin' || currentUser.role === 'tutor'}
          />
        </div>
      )}
    </div>
  );
};

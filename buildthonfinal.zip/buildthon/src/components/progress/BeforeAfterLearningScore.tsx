import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Award, 
  BarChart3, 
  CheckCircle, 
  Plus, 
  ArrowUpRight, 
  Calendar, 
  User, 
  BookOpen, 
  Sparkles, 
  Filter,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { storage } from '../../services/storage';
import { LearningScoreAssessment, SessionRequest, UserProfile } from '../../types';

interface BeforeAfterLearningScoreProps {
  currentUser?: UserProfile;
}

export const BeforeAfterLearningScore: React.FC<BeforeAfterLearningScoreProps> = ({
  currentUser
}) => {
  const activeUser = currentUser || storage.getCurrentUser();
  const [assessments, setAssessments] = useState<LearningScoreAssessment[]>([]);
  const [completedSessions, setCompletedSessions] = useState<SessionRequest[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    sessionId: '',
    subject: 'Data Structures and Algorithms',
    topic: 'AVL Trees & Rotations',
    tutorName: 'Marcus Vance',
    preScore: 4,
    postScore: 9,
    maxScore: 10,
    feedbackNotes: 'Student quickly grasped single and double tree rotations after visual diagrams.',
    nextStepsInput: 'Solve 3 AVL tree practice problems, Review B-tree split algorithms'
  });

  const loadData = () => {
    if (!activeUser) return;
    const scores = storage.getLearningScores(activeUser.role === 'learner' ? activeUser.id : undefined);
    setAssessments(scores);

    const allSessions = storage.getSessions();
    const finished = allSessions.filter((s: SessionRequest) => 
      s.status === 'completed' && (s.learnerId === activeUser.id || s.tutorId === activeUser.id)
    );
    setCompletedSessions(finished);
  };

  useEffect(() => {
    loadData();
  }, [activeUser?.id]);

  const filteredAssessments = selectedSubject === 'All'
    ? assessments
    : assessments.filter(a => a.subject === selectedSubject);

  const subjects = ['All', ...Array.from(new Set(assessments.map(a => a.subject)))];

  // Calculate high-level metrics
  const totalAssessments = filteredAssessments.length;
  const avgDelta = totalAssessments > 0
    ? (filteredAssessments.reduce((acc, a) => acc + a.scoreDelta, 0) / totalAssessments).toFixed(1)
    : '0';
  const avgImprovementPercent = totalAssessments > 0
    ? Math.round(filteredAssessments.reduce((acc, a) => acc + (a.improvementPercent || a.deltaPercentage || 0), 0) / totalAssessments)
    : 0;

  // Chart data preparation
  const chartData = filteredAssessments.map(a => {
    const pre = a.preScore ?? a.preQuizScore ?? 0;
    const post = a.postScore ?? a.postQuizScore ?? 0;
    const max = a.maxScore ?? 10;
    return {
      name: a.topic.length > 15 ? a.topic.substring(0, 15) + '...' : a.topic,
      fullTopic: a.topic,
      'Pre-Session': pre,
      'Post-Session': post,
      'Max': max,
      'Delta': a.scoreDelta
    };
  });

  const handleCreateAssessment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUser) return;

    const pre = Number(formData.preScore);
    const post = Number(formData.postScore);
    const max = Number(formData.maxScore);
    const delta = post - pre;
    const improvementPercent = Math.round((delta / max) * 100);

    const steps = formData.nextStepsInput
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    const nowIso = new Date().toISOString();
    const newAssessment: LearningScoreAssessment = {
      id: `score_${Date.now()}`,
      sessionId: formData.sessionId || `sess_${Date.now()}`,
      learnerId: activeUser.id,
      studentId: activeUser.id,
      tutorId: 'tutor_eval',
      tutorName: formData.tutorName,
      subject: formData.subject,
      topic: formData.topic,
      preQuizScore: pre,
      postQuizScore: post,
      preScore: pre,
      postScore: post,
      maxScore: max,
      scoreDelta: delta,
      deltaPercentage: improvementPercent,
      improvementPercent: improvementPercent,
      date: nowIso.split('T')[0],
      completedAt: nowIso,
      feedbackNotes: formData.feedbackNotes,
      nextSteps: steps
    };

    storage.saveLearningScore(newAssessment);
    
    // Reward user with +25 XP
    storage.awardXP(activeUser.id, 25, `Logged learning improvement for ${formData.topic}`);

    setAssessments(prev => [newAssessment, ...prev]);
    setShowAddModal(false);
    setToastMessage(`Assessment recorded! Average gain: +${delta} pts (+25 XP awarded)`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 bg-emerald-600 text-white font-medium rounded-xl shadow-xl shadow-emerald-500/20 animate-bounce">
          <Sparkles className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-950/70 via-slate-900 to-purple-950/70 border border-indigo-500/20 p-6 md:p-8 backdrop-blur-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 mb-3">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
              Empirical Knowledge Delta Engine
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
              Before & After Learning Score
            </h1>
            <p className="mt-1 text-slate-300 text-sm md:text-base max-w-2xl">
              Verify actual peer tutoring efficacy through rigorous pre-session diagnostics and post-session mastery evaluations.
              No arbitrary claims—only recorded, transparent academic score deltas.
            </p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold shadow-lg shadow-indigo-500/25 transition-all cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Record Assessment
          </button>
        </div>
      </div>

      {/* High-level Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Avg Score Delta</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">+{avgDelta}</span>
            <span className="text-xs text-emerald-400 font-medium">pts / 10 max</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">Average lift across peer tutoring sessions</p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Avg Mastery Gain</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-indigo-400">+{avgImprovementPercent}%</span>
            <span className="text-xs text-slate-400">relative improvement</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">Evaluated on identical topic rubrics</p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Verified Assessments</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">{totalAssessments}</span>
            <span className="text-xs text-purple-400">sessions evaluated</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">Paired pre & post quiz records</p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Next Practice Milestones</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-amber-400">
              {filteredAssessments.reduce((acc, a) => acc + (a.nextSteps?.length || 0), 0)}
            </span>
            <span className="text-xs text-slate-400">actionable tasks</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">Recommended by mentors post-session</p>
        </div>
      </div>

      {/* Subject Filter Bar */}
      <div className="flex items-center justify-between overflow-x-auto pb-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5 mr-2">
            <Filter className="w-3.5 h-3.5" /> Filter by Subject:
          </span>
          {subjects.map(subj => (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all ${
                selectedSubject === subj
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                  : 'bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Card */}
      {chartData.length > 0 && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 backdrop-blur-xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-400" />
                Pre-Session vs Post-Session Score Comparison
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Visualizing student score shifts on a 10-point mastery scale
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-slate-400">
                <span className="w-3 h-3 rounded bg-slate-600 inline-block" /> Pre-Session Quiz
              </span>
              <span className="flex items-center gap-1.5 text-indigo-400 font-semibold">
                <span className="w-3 h-3 rounded bg-indigo-500 inline-block" /> Post-Session Quiz
              </span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis 
                  dataKey="name" 
                  stroke="#94a3b8" 
                  fontSize={12} 
                  tickLine={false} 
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} domain={[0, 10]} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0f172a', 
                    borderColor: '#334155', 
                    borderRadius: '0.75rem', 
                    color: '#f8fafc',
                    boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)'
                  }} 
                  formatter={(val: any, name: any) => [`${val} / 10 pts`, name]}
                  labelFormatter={(_: any, payload: any) => payload[0]?.payload?.fullTopic || ''}
                />
                <Legend verticalAlign="top" height={36} />
                <Bar dataKey="Pre-Session" fill="#64748b" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Post-Session" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Detailed Assessment Cards */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          Recorded Topic Assessments ({filteredAssessments.length})
        </h3>

        {filteredAssessments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredAssessments.map(assessment => {
              const pre = assessment.preScore ?? assessment.preQuizScore ?? 0;
              const post = assessment.postScore ?? assessment.postQuizScore ?? 0;
              const max = assessment.maxScore ?? 10;
              const pct = assessment.improvementPercent ?? assessment.deltaPercentage ?? 0;
              const completedDate = assessment.completedAt || assessment.date || '';

              return (
                <div 
                  key={assessment.id}
                  className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 hover:border-slate-700 transition-all flex flex-col justify-between backdrop-blur-xl"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            {assessment.subject}
                          </span>
                          {assessment.isDemoSample && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              SAMPLE DATA
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-white text-base mt-2">{assessment.topic}</h4>
                        <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-1">
                          <User className="w-3.5 h-3.5 text-slate-500" />
                          Taught by <span className="text-slate-300 font-medium">{assessment.tutorName}</span>
                        </p>
                      </div>

                      <div className="text-right">
                        <div className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-sm">
                          <ArrowUpRight className="w-4 h-4" />
                          +{assessment.scoreDelta} pts
                        </div>
                        <div className="text-[11px] text-emerald-400/80 mt-1 font-semibold">
                          +{pct}% gain
                        </div>
                      </div>
                    </div>

                    {/* Pre vs Post Score Bars */}
                    <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800/80 space-y-2.5 mb-4">
                      <div>
                        <div className="flex justify-between text-xs text-slate-400 mb-1">
                          <span>Pre-Session Diagnostic:</span>
                          <span className="font-semibold text-slate-300">{pre} / {max} pts</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-700 overflow-hidden">
                          <div 
                            className="h-full bg-slate-500" 
                            style={{ width: `${(pre / max) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs text-slate-400 mb-1">
                          <span>Post-Session Evaluation:</span>
                          <span className="font-semibold text-indigo-400">{post} / {max} pts</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-700 overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400" 
                            style={{ width: `${(post / max) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Tutor Feedback Note */}
                    {assessment.feedbackNotes && (
                      <div className="text-xs text-slate-300 mb-4 bg-slate-800/20 p-3 rounded-xl border border-slate-800/50">
                        <span className="font-semibold text-indigo-300">Tutor Feedback: </span>
                        "{assessment.feedbackNotes}"
                      </div>
                    )}

                    {/* Next Steps */}
                    {assessment.nextSteps && assessment.nextSteps.length > 0 && (
                      <div>
                        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                          Next Recommended Milestones:
                        </div>
                        <ul className="space-y-1.5">
                          {assessment.nextSteps.map((step: string, idx: number) => (
                            <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                              <span>{step}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {completedDate ? new Date(completedDate).toLocaleDateString(undefined, { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                      }) : 'Recent'}
                    </span>
                    <span className="text-indigo-400 font-mono">Verified Session Rubric</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-12 text-center backdrop-blur-xl">
            <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h4 className="text-base font-bold text-white mb-1">No Assessments Found</h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
              Complete peer tutoring sessions and log your pre/post quiz scores to track real mastery improvement over time.
            </p>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-500 transition-colors"
            >
              Log Session Assessment
            </button>
          </div>
        )}
      </div>

      {/* Record Assessment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 md:p-8 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-400" />
              Record Before-and-After Evaluation
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Compare your topic quiz score before tutoring against your score after the session.
            </p>

            <form onSubmit={handleCreateAssessment} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Subject Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={e => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="e.g. Data Structures and Algorithms"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Specific Topic
                </label>
                <input
                  type="text"
                  required
                  value={formData.topic}
                  onChange={e => setFormData({ ...formData, topic: e.target.value })}
                  placeholder="e.g. Dynamic Programming (0/1 Knapsack)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Tutor / Peer Mentor
                </label>
                <input
                  type="text"
                  required
                  value={formData.tutorName}
                  onChange={e => setFormData({ ...formData, tutorName: e.target.value })}
                  placeholder="e.g. Marcus Vance"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Pre Score
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={10}
                    required
                    value={formData.preScore}
                    onChange={e => setFormData({ ...formData, preScore: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Post Score
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={10}
                    required
                    value={formData.postScore}
                    onChange={e => setFormData({ ...formData, postScore: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Max Scale
                  </label>
                  <input
                    type="number"
                    readOnly
                    value={formData.maxScore}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 text-sm"
                  />
                </div>
              </div>

              {/* Calculated Delta Preview */}
              <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between text-xs">
                <span className="text-slate-300">Computed Delta Gain:</span>
                <span className="font-bold text-emerald-400 text-sm">
                  {formData.postScore >= formData.preScore ? `+${formData.postScore - formData.preScore}` : `${formData.postScore - formData.preScore}`} Points
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Tutor Feedback Notes
                </label>
                <textarea
                  rows={2}
                  value={formData.feedbackNotes}
                  onChange={e => setFormData({ ...formData, feedbackNotes: e.target.value })}
                  placeholder="Feedback on what clicked or areas for continued practice"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Actionable Next Steps (Comma-separated)
                </label>
                <input
                  type="text"
                  value={formData.nextStepsInput}
                  onChange={e => setFormData({ ...formData, nextStepsInput: e.target.value })}
                  placeholder="e.g. Practice 3 problems, Read lecture slides, Retake quiz"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-semibold shadow-lg shadow-indigo-500/25 transition-all"
                >
                  Save & Earn 25 XP
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

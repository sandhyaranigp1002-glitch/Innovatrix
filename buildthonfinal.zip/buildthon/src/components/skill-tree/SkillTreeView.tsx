import React, { useState } from 'react';
import {
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  ChevronRight,
  Circle,
  Cpu,
  Database,
  GitBranch,
  Globe,
  Layers,
  Lock,
  Sparkles,
  Terminal,
  Zap,
} from 'lucide-react';
import { SkillTreeNode, UserProfile } from '../../types';

interface SkillTreeViewProps {
  nodes: SkillTreeNode[];
  onCompleteMilestone: (nodeId: string, milestoneId: string) => void;
  currentUser: UserProfile;
  onBookSubjectTutor: (subject: string) => void;
}

export const SkillTreeView: React.FC<SkillTreeViewProps> = ({
  nodes,
  onCompleteMilestone,
  currentUser,
  onBookSubjectTutor,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'programming' | 'core_cs' | 'problem_solving' | 'emerging_tech'
  >('all');
  const [selectedNodeId, setSelectedNodeId] = useState<string>(nodes[0]?.id || 'node_prog_1');

  const filteredNodes = nodes.filter((n) => {
    if (selectedCategory === 'all') return true;
    return n.category === selectedCategory;
  });

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  // Helper for node icon
  const getNodeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cpu':
        return Cpu;
      case 'Layers':
        return Layers;
      case 'Database':
        return Database;
      case 'Terminal':
        return Terminal;
      case 'Globe':
        return Globe;
      case 'BrainCircuit':
        return BrainCircuit;
      default:
        return GitBranch;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-50 border border-violet-200 text-violet-700 text-xs font-bold mb-2">
            <GitBranch className="w-3.5 h-3.5" />
            Visual Academic Roadmap
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Interactive Engineering Skill Tree
          </h1>
          <p className="text-sm text-slate-600 max-w-xl mt-1 leading-relaxed">
            Trace foundational prerequisites and unlock advanced coursework milestones through verified peer learning sessions and project proofs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500">
            {nodes.filter((n) => n.isCompleted).length} / {nodes.length} Nodes Mastered
          </span>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap items-center gap-2">
        {[
          { id: 'all', label: 'All Learning Paths' },
          { id: 'programming', label: 'Programming & Languages' },
          { id: 'core_cs', label: 'Core Computer Science' },
          { id: 'problem_solving', label: 'Data Structures & Algorithms' },
          { id: 'emerging_tech', label: 'AI & Machine Learning' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id as any)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition ${
              selectedCategory === cat.id
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Main Interactive Grid: Tree View Left, Node Details Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Node Grid (2 cols) */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Curriculum Progression Matrix
            </h3>
            <span className="text-xs text-slate-400">Click any node to inspect milestones</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredNodes.map((node) => {
              const Icon = getNodeIcon(node.icon);
              const isSelected = node.id === selectedNode.id;
              const completedCount = node.milestones.filter((m) => m.completed).length;

              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`p-5 rounded-2xl border cursor-pointer transition relative flex flex-col justify-between ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-600/20 shadow-md'
                      : node.isCompleted
                      ? 'border-emerald-200 bg-emerald-50/30 hover:border-emerald-300'
                      : node.isUnlocked
                      ? 'border-slate-200 bg-white hover:border-indigo-300'
                      : 'border-slate-200/60 bg-slate-50/60 opacity-60'
                  }`}
                >
                  <div>
                    {/* Header: Level & Status */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                            node.isCompleted
                              ? 'bg-emerald-100 text-emerald-800'
                              : node.isUnlocked
                              ? 'bg-indigo-100 text-indigo-700'
                              : 'bg-slate-200 text-slate-400'
                          }`}
                        >
                          {node.isUnlocked ? <Icon className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                          {node.category.replace('_', ' ')}
                        </span>
                      </div>

                      <span
                        className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                          node.isCompleted
                            ? 'bg-emerald-100 text-emerald-800'
                            : node.isUnlocked
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {node.isCompleted ? 'Mastered' : node.isUnlocked ? 'Unlocked' : 'Locked'}
                      </span>
                    </div>

                    <h4 className="font-extrabold text-sm text-slate-900 leading-tight">
                      {node.title}
                    </h4>
                    <p className="text-xs text-indigo-600 font-semibold mt-0.5">
                      {node.subject}
                    </p>

                    {/* Milestones count */}
                    <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
                      <span>Milestones</span>
                      <span className="font-bold text-slate-700">
                        {completedCount} / {node.milestones.length}
                      </span>
                    </div>

                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          node.isCompleted ? 'bg-emerald-500' : 'bg-indigo-600'
                        }`}
                        style={{
                          width: `${(completedCount / node.milestones.length) * 100}%`,
                        }}
                      />
                    </div>
                  </div>

                  {/* Prerequisites indicator */}
                  {node.prerequisites.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-slate-100 text-[10px] text-slate-400">
                      Prereq: {node.prerequisites.join(', ')}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Node Details Drawer (1 col) */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between space-y-6">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Node Inspector
              </span>
              <span
                className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                  selectedNode.isCompleted
                    ? 'bg-emerald-100 text-emerald-800'
                    : selectedNode.isUnlocked
                    ? 'bg-indigo-100 text-indigo-800'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {selectedNode.isCompleted ? 'Completed' : selectedNode.isUnlocked ? 'In Progress' : 'Prerequisites Pending'}
              </span>
            </div>

            <div className="mt-4 space-y-2">
              <h3 className="text-lg font-black text-slate-900">{selectedNode.title}</h3>
              <p className="text-xs text-indigo-600 font-semibold">{selectedNode.subject}</p>
              <p className="text-xs text-slate-500 leading-relaxed">
                Complete all hands-on milestones below to master this learning node and advance to downstream curriculum paths.
              </p>
            </div>

            {/* Milestones Checklist */}
            <div className="mt-6 space-y-3">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Required Milestones (+50 XP Each):
              </span>

              {selectedNode.milestones.map((m) => (
                <div
                  key={m.id}
                  className={`p-3.5 rounded-2xl border transition flex items-start gap-3 ${
                    m.completed
                      ? 'border-emerald-200 bg-emerald-50/40 text-emerald-950'
                      : selectedNode.isUnlocked
                      ? 'border-slate-200 bg-slate-50 hover:border-indigo-300'
                      : 'border-slate-200/60 bg-slate-50/40 opacity-50'
                  }`}
                >
                  <button
                    disabled={!selectedNode.isUnlocked || m.completed}
                    onClick={() => onCompleteMilestone(selectedNode.id, m.id)}
                    className="mt-0.5 focus:outline-none"
                    title={m.completed ? 'Milestone Completed' : 'Click to complete milestone'}
                  >
                    {m.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100 shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 hover:text-indigo-600 transition shrink-0" />
                    )}
                  </button>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-bold text-slate-900 leading-tight">
                        {m.title}
                      </p>
                      <span className="text-[10px] font-black text-amber-600">
                        +{m.xpReward} XP
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-snug">
                      {m.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action CTA: Book tutor for this subject */}
          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => onBookSubjectTutor(selectedNode.subject)}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition flex items-center justify-center gap-2"
            >
              <span>Find Mentors for {selectedNode.subject.split(' ')[0]}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

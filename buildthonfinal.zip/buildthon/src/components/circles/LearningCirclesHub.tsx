import React, { useState } from 'react';
import {
  Calendar,
  Check,
  ExternalLink,
  Heart,
  MessageSquare,
  Plus,
  Send,
  Sparkles,
  Tag,
  UserPlus,
  Users2,
  Video,
  X,
} from 'lucide-react';
import { LearningCircle, UserProfile } from '../../types';

interface LearningCirclesHubProps {
  circles: LearningCircle[];
  currentUser: UserProfile;
  onCreateCircle: (circleData: {
    name: string;
    subject: string;
    description: string;
    learningGoal: string;
    tags: string[];
    maxMembers: number;
  }) => void;
  onJoinCircle: (circleId: string) => void;
  onLeaveCircle: (circleId: string) => void;
  onPostUpdate: (circleId: string, content: string) => void;
  onToggleLike: (circleId: string, updateId: string) => void;
}

export const LearningCirclesHub: React.FC<LearningCirclesHubProps> = ({
  circles,
  currentUser,
  onCreateCircle,
  onJoinCircle,
  onLeaveCircle,
  onPostUpdate,
  onToggleLike,
}) => {
  const [selectedCircleId, setSelectedCircleId] = useState<string>(
    circles[0]?.id || ''
  );
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [updateText, setUpdateText] = useState<string>('');

  // Create modal state
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('Data Structures');
  const [description, setDescription] = useState('');
  const [learningGoal, setLearningGoal] = useState('');
  const [tagsStr, setTagsStr] = useState('Algorithms, Midterm Prep');

  const selectedCircle =
    circles.find((c) => c.id === selectedCircleId) || circles[0];
  const isMember = selectedCircle?.members.some(
    (m) => m.userId === currentUser.id
  );

  const handlePostUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateText.trim() || !selectedCircle) return;
    onPostUpdate(selectedCircle.id, updateText.trim());
    setUpdateText('');
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !description.trim() || !learningGoal.trim()) return;

    const tags = tagsStr
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    onCreateCircle({
      name: name.trim(),
      subject,
      description: description.trim(),
      learningGoal: learningGoal.trim(),
      tags,
      maxMembers: 10,
    });

    setName('');
    setDescription('');
    setLearningGoal('');
    setShowCreateModal(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold mb-2">
            <Users2 className="w-3.5 h-3.5" />
            Collaborative Peer-Study Squads
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Learning Circles
          </h1>
          <p className="text-sm text-slate-600 max-w-xl mt-1 leading-relaxed">
            Form or join small, focused student study groups to tackle difficult problem sets, host weekly whiteboard sessions, and hold each other accountable.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 transition active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create Learning Circle</span>
        </button>
      </div>

      {/* Main Content: Empty State or Grid */}
      {circles.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
            <Users2 className="w-8 h-8" />
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h3 className="text-lg font-bold text-slate-800">No Learning Circles yet</h3>
            <p className="text-xs text-slate-500">
              Be the first! Form a collaborative peer study circle for your subject, upcoming exams, or group project.
            </p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition active:scale-95 inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Create First Learning Circle</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Circle List */}
        <div className="lg:col-span-1 space-y-3">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block px-1">
            Active Campus Circles ({circles.length})
          </span>

          {circles.map((circle) => {
            const isSelected = circle.id === selectedCircle?.id;
            const amMember = circle.members.some(
              (m) => m.userId === currentUser.id
            );
            return (
              <div
                key={circle.id}
                onClick={() => setSelectedCircleId(circle.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition space-y-2 ${
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600 shadow-sm'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="font-extrabold text-sm text-slate-900">
                    {circle.name}
                  </h4>
                  {amMember && (
                    <span className="text-[10px] uppercase font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full shrink-0">
                      Joined
                    </span>
                  )}
                </div>

                <p className="text-xs text-indigo-600 font-medium">
                  {circle.subject} &bull; {circle.members.length}/{circle.maxMembers} Members
                </p>

                <p className="text-xs text-slate-500 line-clamp-2">
                  {circle.description}
                </p>

                <div className="flex flex-wrap gap-1 pt-1">
                  {circle.tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-medium"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Selected Circle Workspace */}
        {selectedCircle && (
          <div className="lg:col-span-2 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-6">
            {/* Circle Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  {selectedCircle.subject}
                </span>
                <h2 className="text-xl font-black text-slate-900">
                  {selectedCircle.name}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {selectedCircle.description}
                </p>
              </div>

              <div>
                {isMember ? (
                  <button
                    onClick={() => onLeaveCircle(selectedCircle.id)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition"
                  >
                    Leave Circle
                  </button>
                ) : (
                  <button
                    onClick={() => onJoinCircle(selectedCircle.id)}
                    className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition active:scale-95"
                  >
                    Join Study Circle &rarr;
                  </button>
                )}
              </div>
            </div>

            {/* Shared Goal & Upcoming Session */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 text-xs">
                <span className="font-bold text-amber-900 uppercase tracking-wider block mb-1">
                  Shared Objective
                </span>
                <p className="text-amber-950 font-medium leading-relaxed">
                  "{selectedCircle.learningGoal}"
                </p>
              </div>

              {selectedCircle.upcomingSession && (
                <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-200 text-xs flex flex-col justify-between">
                  <div>
                    <span className="font-bold text-indigo-900 uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      Next Group Session
                    </span>
                    <p className="font-bold text-indigo-950">
                      {selectedCircle.upcomingSession.topic}
                    </p>
                    <p className="text-[11px] text-indigo-700 mt-0.5">
                      {selectedCircle.upcomingSession.date} at {selectedCircle.upcomingSession.time}
                    </p>
                  </div>
                  <a
                    href={selectedCircle.upcomingSession.meetingLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 text-indigo-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Launch Meet Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>

            {/* Members Row */}
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Study Squad Members ({selectedCircle.members.length})
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedCircle.members.map((member) => (
                  <div
                    key={member.userId}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  >
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="font-semibold text-slate-800">
                      {member.name}
                    </span>
                    {member.role === 'leader' && (
                      <span className="text-[9px] uppercase font-bold text-amber-800 bg-amber-100 px-1 rounded">
                        Host
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Knowledge Feed / Updates */}
            <div className="space-y-4 pt-2 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Study Updates &amp; Notes Feed
              </span>

              {/* Input for post */}
              {isMember ? (
                <form onSubmit={handlePostUpdate} className="flex gap-2">
                  <input
                    type="text"
                    value={updateText}
                    onChange={(e) => setUpdateText(e.target.value)}
                    placeholder="Share a study tip, whiteboard snapshot, or problem link with your squad..."
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:border-indigo-500 outline-none"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Post (+15 XP)</span>
                  </button>
                </form>
              ) : (
                <p className="text-xs text-slate-400 italic">
                  Join this circle to participate in knowledge discussions and post updates.
                </p>
              )}

              {/* Updates List */}
              <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                {selectedCircle.updates.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4">
                    No updates posted in this circle yet. Be the first to share!
                  </p>
                ) : (
                  selectedCircle.updates.map((update) => (
                    <div
                      key={update.id}
                      className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <img
                            src={update.userAvatar}
                            alt={update.userName}
                            className="w-6 h-6 rounded-full object-cover"
                          />
                          <span className="font-bold text-slate-900">
                            {update.userName}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(update.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      <p className="text-slate-700 leading-relaxed pl-8">
                        {update.content}
                      </p>

                      <div className="pl-8 pt-1 flex items-center gap-2">
                        <button
                          onClick={() =>
                            onToggleLike(selectedCircle.id, update.id)
                          }
                          className={`flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md transition ${
                            update.likedByMe
                              ? 'text-rose-600 bg-rose-50'
                              : 'text-slate-400 hover:text-slate-600'
                          }`}
                        >
                          <Heart
                            className={`w-3.5 h-3.5 ${
                              update.likedByMe ? 'fill-rose-500' : ''
                            }`}
                          />
                          <span>{update.likes}</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    )}

      {/* Create Circle Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">
                Create a Learning Circle
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 mt-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Circle Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Distributed Systems Reading Group"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Primary Subject
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-indigo-500 bg-white"
                >
                  {[
                    'Data Structures',
                    'Algorithms',
                    'Operating Systems',
                    'DBMS',
                    'Computer Networks',
                    'Machine Learning',
                    'Mathematics',
                  ].map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Circle Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What is the group focus? When will you meet?"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Shared Learning Goal
                </label>
                <input
                  type="text"
                  value={learningGoal}
                  onChange={(e) => setLearningGoal(e.target.value)}
                  placeholder="e.g. Finish the 30-day LeetCode challenge"
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={tagsStr}
                  onChange={(e) => setTagsStr(e.target.value)}
                  placeholder="e.g. Python, Graphs, Mock Interviews"
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-md shadow-indigo-600/20"
                >
                  Create (+50 XP)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

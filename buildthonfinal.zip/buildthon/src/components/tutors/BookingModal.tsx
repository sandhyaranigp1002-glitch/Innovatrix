import React, { useState } from 'react';
import {
  AlertCircle,
  Calendar,
  CheckCircle2,
  Clock,
  GraduationCap,
  Info,
  MapPin,
  Sparkles,
  Video,
  X,
} from 'lucide-react';
import { AvailabilitySlot, TutorProfile, UserProfile } from '../../types';
import { LocalStorageAdapter } from '../../services/storage';

interface BookingModalProps {
  tutor: UserProfile;
  tutorProfile: TutorProfile;
  slots: AvailabilitySlot[];
  learner: UserProfile;
  onConfirmBooking: (bookingData: {
    slotId: string;
    subject: string;
    learningGoal: string;
    mode: 'online' | 'in_person';
    date: string;
    startTime: string;
    endTime: string;
    locationOrLink: string;
  }) => void;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  tutor,
  tutorProfile,
  slots,
  learner,
  onConfirmBooking,
  onClose,
}) => {
  const [selectedSlotId, setSelectedSlotId] = useState<string>(
    slots.find((s) => !s.isBooked)?.id || ''
  );
  const [selectedSubject, setSelectedSubject] = useState<string>(
    tutorProfile.subjects[0]?.subject || 'Python'
  );
  const [learningGoal, setLearningGoal] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [joinedWaitlist, setJoinedWaitlist] = useState<boolean>(false);

  const selectedSlot = slots.find((s) => s.id === selectedSlotId);
  const openSlots = slots.filter((s) => !s.isBooked);

  // Self-booking prevention
  const isSelfBooking = tutor.id === learner.id;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isSelfBooking) {
      setError('You cannot book a tutoring session with yourself.');
      return;
    }

    if (!selectedSlotId || !selectedSlot) {
      setError('Please select an available time slot.');
      return;
    }

    if (!selectedSubject) {
      setError('Please select a subject to study.');
      return;
    }

    if (!learningGoal.trim() || learningGoal.trim().length < 15) {
      setError('Please enter a specific learning goal (at least 15 characters). e.g., "Need help tracing binary search tree rotations".');
      return;
    }

    onConfirmBooking({
      slotId: selectedSlot.id,
      subject: selectedSubject,
      learningGoal: learningGoal.trim(),
      mode: selectedSlot.mode,
      date: selectedSlot.date,
      startTime: selectedSlot.startTime,
      endTime: selectedSlot.endTime,
      locationOrLink: selectedSlot.locationOrLink,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-8">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <img
              src={tutor.avatar}
              alt={tutor.name}
              className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shadow-sm"
            />
            <div>
              <h3 className="font-extrabold text-lg text-slate-900">
                Book Tutoring with {tutor.name}
              </h3>
              <p className="text-xs text-indigo-600 font-medium">
                {tutor.department} &bull; {tutorProfile.rating.toFixed(1)}★ ({tutorProfile.reviewCount} reviews)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSelfBooking && (
          <div className="my-4 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>You are currently signed in as this tutor. Switch to a learner persona (e.g. Alex Chen) to book sessions.</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Subject Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Select Subject
            </label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
            >
              {tutorProfile.subjects.map((s) => (
                <option key={s.id} value={s.subject}>
                  {s.subject} ({s.skillLevel} level &bull; {s.experienceYears}y exp)
                </option>
              ))}
            </select>
          </div>

          {/* Slot Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Select Guaranteed Available Slot
            </label>
            {openSlots.length === 0 ? (
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs space-y-3">
                <div className="flex items-start gap-2">
                  <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-800">All Published Slots Currently Booked</p>
                    <p className="text-slate-600 mt-0.5">
                      This peer tutor is in high demand. Join their waitlist to get prioritized when a slot frees up or a new schedule is published.
                    </p>
                  </div>
                </div>

                {joinedWaitlist ? (
                  <div className="p-2.5 rounded-lg bg-emerald-100 border border-emerald-300 text-emerald-800 font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>You're on the priority waitlist! We will notify you once a slot opens.</span>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      LocalStorageAdapter.addToWaitlist({
                        tutorId: tutor.id,
                        tutorName: tutor.name,
                        learnerId: learner.id,
                        learnerName: learner.name,
                        learnerEmail: learner.email,
                        subject: selectedSubject,
                        preferredTime: 'Next Available',
                        preferredMode: 'online',
                        notes: learningGoal.trim() || 'Awaiting slot opening'
                      });
                      setJoinedWaitlist(true);
                    }}
                    className="w-full py-2 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Clock className="w-3.5 h-3.5" />
                    Join Priority Waitlist
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                {openSlots.map((slot) => {
                  const isSelected = slot.id === selectedSlotId;
                  return (
                    <div
                      key={slot.id}
                      onClick={() => setSelectedSlotId(slot.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between text-xs ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/60 ring-1 ring-indigo-600 font-semibold'
                          : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Calendar className="w-4 h-4 text-indigo-600 shrink-0" />
                        <div>
                          <p className="text-slate-800 font-medium">
                            {slot.dayOfWeek}, {slot.date}
                          </p>
                          <p className="text-[11px] text-slate-500">
                            {slot.startTime} - {slot.endTime}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] uppercase font-bold ${
                            slot.mode === 'online'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-emerald-100 text-emerald-700'
                          }`}
                        >
                          {slot.mode}
                        </span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-600" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Meeting Location/Link Preview */}
          {selectedSlot && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center gap-2">
              {selectedSlot.mode === 'online' ? (
                <Video className="w-4 h-4 text-indigo-600 shrink-0" />
              ) : (
                <MapPin className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span className="truncate">
                {selectedSlot.mode === 'online' ? 'Virtual Meeting Room: ' : 'Campus Location: '}
                <strong>{selectedSlot.locationOrLink}</strong>
              </span>
            </div>
          )}

          {/* Learning Goal */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Specific Learning Objective *
              </label>
              <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                +45 XP Daily Quest
              </span>
            </div>
            <textarea
              rows={3}
              value={learningGoal}
              onChange={(e) => setLearningGoal(e.target.value)}
              placeholder="e.g. I want to debug my red-black tree insertion code and understand color flipping before the quiz..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-none placeholder-slate-400"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Clear learning goals help mentors prepare relevant code examples and whiteboard exercises.
            </p>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSelfBooking || openSlots.length === 0}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 disabled:opacity-50 text-white font-bold text-xs shadow-md shadow-indigo-600/25 transition"
            >
              Confirm Session Request
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

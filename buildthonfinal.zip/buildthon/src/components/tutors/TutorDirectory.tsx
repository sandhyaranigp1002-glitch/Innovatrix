import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle,
  Clock,
  Compass,
  Filter,
  GraduationCap,
  Info,
  MapPin,
  Search,
  Sparkles,
  Star,
  Users2,
  Video,
} from 'lucide-react';
import { AvailabilitySlot, TeachingStyle, TutorProfile, UserProfile } from '../../types';

interface TutorDirectoryProps {
  tutors: { user: UserProfile; profile: TutorProfile; slots: AvailabilitySlot[] }[];
  onOpenBooking: (tutorId: string) => void;
  onOpenSmartMatcher: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const TutorDirectory: React.FC<TutorDirectoryProps> = ({
  tutors,
  onOpenBooking,
  onOpenSmartMatcher,
  searchQuery,
  onSearchChange,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedMode, setSelectedMode] = useState<'all' | 'online' | 'in_person'>('all');
  const [selectedStyle, setSelectedStyle] = useState<TeachingStyle | 'all'>('all');

  const subjectFilters = [
    'all',
    'Python',
    'Data Structures',
    'Java',
    'DBMS',
    'Operating Systems',
    'Computer Networks',
    'Mathematics',
    'Machine Learning',
  ];

  // Filter tutors
  const filteredTutors = tutors.filter(({ user, profile }) => {
    // Search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const nameMatch = user.name.toLowerCase().includes(q);
      const deptMatch = user.department.toLowerCase().includes(q);
      const subjectMatch = profile.subjects.some((s) => s.subject.toLowerCase().includes(q));
      if (!nameMatch && !deptMatch && !subjectMatch) return false;
    }

    // Subject filter
    if (selectedSubject !== 'all') {
      const hasSubject = profile.subjects.some(
        (s) => s.subject.toLowerCase() === selectedSubject.toLowerCase()
      );
      if (!hasSubject) return false;
    }

    // Mode filter
    if (selectedMode !== 'all') {
      if (!profile.teachingModes.includes(selectedMode)) return false;
    }

    // Style filter
    if (selectedStyle !== 'all') {
      if (profile.teachingStyle !== selectedStyle) return false;
    }

    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner & Smart Match Trigger */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-2">
            <GraduationCap className="w-3.5 h-3.5" />
            Verified Campus Mentors Directory
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Find the Perfect Peer Tutor
          </h1>
          <p className="text-sm text-slate-600 max-w-xl mt-1 leading-relaxed">
            Connect with accomplished students who recently took your exact courses, solved the same lab assignments, and understand the concepts from the inside out.
          </p>
        </div>

        <button
          onClick={onOpenSmartMatcher}
          className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-700 hover:from-indigo-700 hover:to-violet-800 text-white font-extrabold text-sm shadow-xl shadow-indigo-600/25 flex items-center justify-center gap-2.5 transition active:scale-95 shrink-0"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>Launch Smart Matcher</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
        {/* Search input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search by tutor name, subject (e.g. Python, DBMS, OS), or department..."
            className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl outline-none text-slate-800"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-1">
            Subject:
          </span>
          {subjectFilters.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition ${
                selectedSubject === sub
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {sub === 'all' ? 'All Subjects' : sub}
            </button>
          ))}
        </div>

        {/* Secondary filters: Mode & Style */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-500">Mode:</span>
            <select
              value={selectedMode}
              onChange={(e) => setSelectedMode(e.target.value as any)}
              className="p-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-700 outline-none"
            >
              <option value="all">Any Format</option>
              <option value="online">Online Virtual</option>
              <option value="in_person">On-Campus In-Person</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-500">Teaching Style:</span>
            <select
              value={selectedStyle}
              onChange={(e) => setSelectedStyle(e.target.value as any)}
              className="p-1.5 rounded-lg border border-slate-200 bg-white font-medium text-slate-700 outline-none"
            >
              <option value="all">All Styles</option>
              <option value="beginner_friendly">Beginner-Friendly</option>
              <option value="practice_focused">Practice &amp; Coding</option>
              <option value="deep_dive">Deep Dive</option>
              <option value="exam_prep">Exam Prep</option>
            </select>
          </div>

          <span className="text-slate-400 font-medium ml-auto">
            Showing {filteredTutors.length} mentors
          </span>
        </div>
      </div>

      {/* Tutor Cards Grid */}
      {filteredTutors.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white border border-slate-200">
          <Compass className="w-12 h-12 mx-auto text-slate-300 mb-3" />
          <h3 className="text-base font-bold text-slate-800">No mentors match your criteria</h3>
          <p className="text-xs text-slate-500 mt-1">
            Try clearing filters or search for another engineering discipline.
          </p>
          <button
            onClick={() => {
              setSelectedSubject('all');
              setSelectedMode('all');
              setSelectedStyle('all');
              onSearchChange('');
            }}
            className="mt-4 px-4 py-2 bg-indigo-50 text-indigo-700 text-xs font-bold rounded-xl hover:bg-indigo-100 transition"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTutors.map(({ user, profile, slots }) => {
            const openSlots = slots.filter((s) => !s.isBooked);
            return (
              <div
                key={user.id}
                className="p-6 rounded-3xl bg-white border border-slate-200 hover:border-indigo-300 transition flex flex-col justify-between hover:shadow-lg space-y-4"
              >
                <div>
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3.5">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shadow-sm shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-extrabold text-base text-slate-900 leading-tight">
                            {user.name}
                          </h3>
                          {user.verified && (
                            <CheckCircle className="w-4 h-4 text-indigo-600 fill-indigo-100" />
                          )}
                        </div>
                        <p className="text-xs text-indigo-600 font-semibold mt-0.5">
                          {user.department} &bull; {user.academicYear}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          Level {user.level} {user.levelTitle} &bull; {user.streakDays}-Day Streak 🔥
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
                        <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        <span>{profile.rating.toFixed(1)}</span>
                        <span className="text-slate-400 font-normal">({profile.reviewCount})</span>
                      </div>
                    </div>
                  </div>

                  {/* Bio */}
                  <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                    {user.bio}
                  </p>

                  {/* Subjects Offered */}
                  <div className="mt-4 space-y-1.5">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Subjects Taught:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {profile.subjects.map((sub) => (
                        <span
                          key={sub.id}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50/70 border border-indigo-100 text-indigo-900 text-xs font-semibold"
                        >
                          {sub.subject} <span className="text-indigo-400 font-normal">({sub.skillLevel})</span>
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Teaching Style & Mode */}
                  <div className="mt-3.5 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <span className="font-semibold text-slate-700">Style:</span>
                      <span className="capitalize">{profile.teachingStyle.replace('_', ' ')}</span>
                    </span>
                    <span>&bull;</span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{profile.teachingModes.join(', ')}</span>
                    </span>
                  </div>
                </div>

                {/* Footer & Action */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div className="text-xs">
                    <span className="font-bold text-slate-900">{openSlots.length}</span>{' '}
                    <span className="text-slate-500">open slots available</span>
                  </div>

                  <button
                    onClick={() => onOpenBooking(user.id)}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition active:scale-95"
                  >
                    Book Session &rarr;
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

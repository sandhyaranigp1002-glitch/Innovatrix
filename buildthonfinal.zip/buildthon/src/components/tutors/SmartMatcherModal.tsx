import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  Compass,
  GraduationCap,
  HelpCircle,
  MapPin,
  Sparkles,
  Star,
  Video,
  X,
  Zap,
} from 'lucide-react';
import { AvailabilitySlot, TeachingStyle, TutorMatchRecommendation, TutorProfile, UserProfile } from '../../types';
import { MatchingCriteria, rankTutors } from '../../services/matching';

interface SmartMatcherModalProps {
  tutors: { user: UserProfile; profile: TutorProfile; slots: AvailabilitySlot[] }[];
  onSelectTutorToBook: (tutorId: string) => void;
  onClose: () => void;
}

export const SmartMatcherModal: React.FC<SmartMatcherModalProps> = ({
  tutors,
  onSelectTutorToBook,
  onClose,
}) => {
  const [criteria, setCriteria] = useState<MatchingCriteria>({
    subject: 'Data Structures',
    preferredDay: 'any',
    mode: 'all',
    teachingStyle: 'beginner_friendly',
  });

  const subjects = [
    'Python',
    'Data Structures',
    'Java',
    'DBMS',
    'Operating Systems',
    'Computer Networks',
    'Mathematics',
    'Machine Learning',
  ];

  const days = ['any', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const results: TutorMatchRecommendation[] = rankTutors(tutors, criteria);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-8">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-700 text-xs font-bold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              Transparent Rule-Based Matcher
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Smart Mentor Matchmaker
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select your preferences below to calculate weighted scores across subject skills, slot schedules, and teaching pedagogy.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Questionnaire Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 my-6 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
          {/* Subject */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Subject
            </label>
            <select
              value={criteria.subject}
              onChange={(e) => setCriteria({ ...criteria, subject: e.target.value })}
              className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-800 font-medium focus:border-indigo-500 outline-none"
            >
              {subjects.map((sub) => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
          </div>

          {/* Preferred Day */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Preferred Day
            </label>
            <select
              value={criteria.preferredDay}
              onChange={(e) => setCriteria({ ...criteria, preferredDay: e.target.value })}
              className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-800 font-medium focus:border-indigo-500 outline-none"
            >
              {days.map((d) => (
                <option key={d} value={d}>
                  {d === 'any' ? 'Any Available Day' : d}
                </option>
              ))}
            </select>
          </div>

          {/* Mode */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Meeting Mode
            </label>
            <select
              value={criteria.mode}
              onChange={(e) => setCriteria({ ...criteria, mode: e.target.value as any })}
              className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-800 font-medium focus:border-indigo-500 outline-none"
            >
              <option value="all">Online or In-person</option>
              <option value="online">Virtual (Google Meet)</option>
              <option value="in_person">On-Campus (Study Rooms)</option>
            </select>
          </div>

          {/* Teaching Style */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Teaching Style
            </label>
            <select
              value={criteria.teachingStyle}
              onChange={(e) => setCriteria({ ...criteria, teachingStyle: e.target.value as any })}
              className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-800 font-medium focus:border-indigo-500 outline-none"
            >
              <option value="beginner_friendly">Beginner-Friendly</option>
              <option value="practice_focused">Practice &amp; Coding</option>
              <option value="deep_dive">Deep Theoretical Dive</option>
              <option value="exam_prep">Midterm / Exam Prep</option>
              <option value="any">Any Style</option>
            </select>
          </div>
        </div>

        {/* Results List */}
        <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1">
            <span>Ranked Results ({results.length} mentors)</span>
            <span className="text-[11px] text-slate-400">Higher match score = better alignment with your criteria</span>
          </div>

          {results.map(({ tutor, tutorProfile, score, matchReasons, availableSlots }) => (
            <div
              key={tutor.id}
              className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-md transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-4">
                <img
                  src={tutor.avatar}
                  alt={tutor.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shrink-0"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-base text-slate-900">{tutor.name}</h4>
                    <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 flex items-center gap-1">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      {tutorProfile.rating.toFixed(1)}
                    </span>
                    <span className="text-xs text-slate-400">({tutorProfile.reviewCount} reviews)</span>
                  </div>

                  <p className="text-xs text-indigo-600 font-medium">
                    {tutor.department} &bull; {tutor.academicYear}
                  </p>

                  {/* Match score bar & reasons */}
                  <div className="mt-2 space-y-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold text-slate-700">Match Score:</span>
                      <div className="w-24 bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            score >= 80 ? 'bg-emerald-500' : score >= 60 ? 'bg-indigo-500' : 'bg-amber-500'
                          }`}
                          style={{ width: `${score}%` }}
                        />
                      </div>
                      <span className="font-black text-indigo-700">{score}%</span>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {matchReasons.map((reason, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] bg-indigo-50 text-indigo-800 border border-indigo-100 px-2 py-0.5 rounded-lg flex items-center gap-1 font-medium"
                        >
                          <CheckCircle2 className="w-3 h-3 text-indigo-600" />
                          {reason}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="sm:text-right shrink-0">
                <p className="text-xs text-slate-500 mb-2">
                  <strong>{availableSlots.length}</strong> open slots
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onSelectTutorToBook(tutor.id);
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition active:scale-95"
                >
                  Book Session &rarr;
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  AlertCircle,
  Award,
  CheckCircle2,
  GraduationCap,
  HelpCircle,
  Send,
  Sparkles,
  X,
} from 'lucide-react';
import { TeachingStyle, UserProfile } from '../../types';
import { LocalStorageAdapter } from '../../services/storage';

interface TutorApplicationModalProps {
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onSubmitted: () => void;
}

const AVAILABLE_SUBJECTS = [
  'Data Structures & Algorithms',
  'Python for Engineers',
  'Java OOP & System Design',
  'Database Management & SQL',
  'Operating Systems & Concurrency',
  'Computer Networks & Sockets',
  'Linear Algebra & Calculus',
  'Machine Learning Foundations',
];

export const TutorApplicationModal: React.FC<TutorApplicationModalProps> = ({
  currentUser,
  isOpen,
  onClose,
  onSubmitted,
}) => {
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(['Data Structures & Algorithms']);
  const [expertiseSummary, setExpertiseSummary] = useState('');
  const [teachingStyle, setTeachingStyle] = useState<TeachingStyle>('beginner_friendly');
  const [hourlyCredits, setHourlyCredits] = useState<number>(1);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const isVerified = currentUser.verificationStatus === 'approved';

  const toggleSubject = (subj: string) => {
    if (selectedSubjects.includes(subj)) {
      if (selectedSubjects.length > 1) {
        setSelectedSubjects(selectedSubjects.filter((s) => s !== subj));
      }
    } else {
      setSelectedSubjects([...selectedSubjects, subj]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expertiseSummary.trim()) {
      setError('Please provide a brief summary of your qualifications or coursework grades.');
      return;
    }
    if (selectedSubjects.length === 0) {
      setError('Please select at least one subject to tutor.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    setTimeout(() => {
      try {
        LocalStorageAdapter.submitTutorApplication({
          userId: currentUser.id,
          subjects: selectedSubjects,
          expertiseSummary: expertiseSummary.trim(),
          teachingStyle,
          hourlyCredits,
        });
        setIsSubmitting(false);
        onSubmitted();
        onClose();
      } catch (err: any) {
        setIsSubmitting(false);
        setError(err.message || 'Failed to submit application.');
      }
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              👨‍🏫
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Apply to Become a Peer Tutor</h2>
              <p className="text-xs text-slate-500">
                Official faculty & administrative certification process
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          {!isVerified ? (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm text-amber-950 mb-1">
                  PRN Verification Required First
                </p>
                <p className="text-amber-800 leading-relaxed">
                  Only students with approved PRN credentials can apply for peer tutoring certification. Your account is currently{' '}
                  <span className="font-bold underline">{currentUser.verificationStatus?.toUpperCase() || 'PENDING'}</span>.
                  Please wait for registrar verification before submitting a tutor application.
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Notice */}
              <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-100 text-xs text-indigo-900 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  BrainBridge tutors must be vetted by campus administrators before gaining permissions to publish availability slots and accept bookings.
                </p>
              </div>

              {error && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Applicant Info (Pre-filled & verified) */}
              <div className="grid grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block">Applicant Name</span>
                  <span className="font-bold text-slate-800">{currentUser.name}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Verified Student PRN</span>
                  <span className="font-mono font-bold text-emerald-700">
                    {currentUser.prnMasked || 'PRN-****-Verified'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Department</span>
                  <span className="font-semibold text-slate-700">{currentUser.department}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Academic Year</span>
                  <span className="font-semibold text-slate-700">{currentUser.academicYear}</span>
                </div>
              </div>

              {/* Subjects Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Subjects You Wish to Tutor *
                </label>
                <div className="flex flex-wrap gap-2">
                  {AVAILABLE_SUBJECTS.map((subj) => {
                    const isSelected = selectedSubjects.includes(subj);
                    return (
                      <button
                        type="button"
                        key={subj}
                        onClick={() => toggleSubject(subj)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {subj}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Qualifications / Coursework */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Academic Qualifications & Grades *
                </label>
                <textarea
                  rows={3}
                  value={expertiseSummary}
                  onChange={(e) => setExpertiseSummary(e.target.value)}
                  placeholder="e.g. Scored an A in CS201 Data Structures. Completed competitive programming track. Teaching Assistant for introductory lab sections."
                  required
                  className="w-full p-3 rounded-xl border border-slate-200 text-slate-800 text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                />
              </div>

              {/* Teaching Style */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Preferred Teaching Style
                  </label>
                  <select
                    value={teachingStyle}
                    onChange={(e) => setTeachingStyle(e.target.value as TeachingStyle)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="beginner_friendly">Beginner-Friendly & Patient</option>
                    <option value="practice_focused">Problem-Solving & Coding Labs</option>
                    <option value="deep_dive">Theoretical Deep-Dive & Architecture</option>
                    <option value="exam_prep">Exam Prep & Past Papers</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Hourly Credits
                  </label>
                  <select
                    value={hourlyCredits}
                    onChange={(e) => setHourlyCredits(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value={1}>1 Credit / hr (Campus Standard)</option>
                    <option value={2}>2 Credits / hr (Advanced Topics)</option>
                  </select>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit for Admin Approval</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

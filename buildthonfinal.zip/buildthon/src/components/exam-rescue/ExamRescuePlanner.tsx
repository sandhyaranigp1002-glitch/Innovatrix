import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  Calendar, 
  CheckCircle2, 
  Circle, 
  Clock, 
  Flame, 
  Plus, 
  RefreshCw, 
  Sparkles, 
  Trash2, 
  UserCheck, 
  BookOpen, 
  GraduationCap, 
  ChevronRight,
  HelpCircle
} from 'lucide-react';
import { storage } from '../../services/storage';
import { ExamRescuePlan, ExamRescueTask, TutorProfile, UserProfile } from '../../types';

interface ExamRescuePlannerProps {
  currentUser?: UserProfile;
  onNavigateToKnowledgeCheck?: (subject: string) => void;
  onNavigateToTutors?: (subject: string) => void;
}

export const ExamRescuePlanner: React.FC<ExamRescuePlannerProps> = ({
  currentUser,
  onNavigateToKnowledgeCheck,
  onNavigateToTutors
}) => {
  const activeUser = currentUser || storage.getCurrentUser();
  const [plans, setPlans] = useState<ExamRescuePlan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [tutors, setTutors] = useState<{ user: UserProfile; profile: TutorProfile }[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    subject: 'Database Management Systems',
    examDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    topicsInput: 'Relational Algebra, Normalization (1NF-BCNF), Indexing, SQL Joins, ACID Properties',
    weakTopicsInput: 'Normalization (1NF-BCNF), B+ Tree Indexing',
    confidence: 2,
    dailyMinutes: 90
  });

  const loadData = () => {
    if (!activeUser) return;
    const userPlans = storage.getExamRescuePlans(activeUser.id);
    setPlans(userPlans);
    if (userPlans.length > 0 && !selectedPlanId) {
      setSelectedPlanId(userPlans[0].id);
    } else if (userPlans.length === 0) {
      setSelectedPlanId(null);
    }
    const allProfiles = storage.getTutorProfiles();
    const allUsers = storage.getUsers();
    const paired = allProfiles
      .map(p => {
        const u = allUsers.find(user => user.id === p.userId);
        return u ? { profile: p, user: u } : null;
      })
      .filter((item): item is { profile: TutorProfile; user: UserProfile } => item !== null);
    setTutors(paired);
  };

  useEffect(() => {
    loadData();
  }, [activeUser?.id]);

  const activePlan = plans.find(p => p.id === selectedPlanId) || plans[0] || null;

  // Calculate countdown
  const getCountdown = (dateString: string) => {
    const examTime = new Date(dateString).getTime();
    const diff = examTime - Date.now();
    if (diff <= 0) return { days: 0, hours: 0, isPast: true };
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    return { days, hours, isPast: false };
  };

  const handleToggleTask = (taskId: string) => {
    if (!activePlan) return;
    const updated = storage.toggleExamRescueTask(activePlan.id, taskId);
    if (updated) {
      setPlans(prev => prev.map(p => p.id === updated.id ? updated : p));
      const toggled = updated.tasks.find((t: ExamRescueTask) => t.id === taskId);
      const isTaskDone = toggled?.isCompleted || toggled?.completed;
      if (isTaskDone) {
        setToastMessage(`Task completed! +15 XP earned.`);
        setTimeout(() => setToastMessage(null), 3500);
      }
    }
  };

  const handleRescheduleMissed = () => {
    if (!activePlan) return;
    const today = new Date().toISOString().split('T')[0];
    const updatedTasks: ExamRescueTask[] = activePlan.tasks.map((t: ExamRescueTask) => {
      const taskDueDate = t.dueDate || t.scheduledDate;
      const isTaskDone = t.isCompleted || t.completed;
      if (!isTaskDone && new Date(taskDueDate) < new Date(today)) {
        return { ...t, dueDate: today, scheduledDate: today };
      }
      return t;
    });
    const updatedPlan: ExamRescuePlan = {
      ...activePlan,
      tasks: updatedTasks
    };
    storage.saveExamRescuePlan(updatedPlan);
    setPlans(prev => prev.map(p => p.id === updatedPlan.id ? updatedPlan : p));
    setToastMessage('Overdue tasks rescheduled to today!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDeletePlan = (planId: string) => {
    storage.deleteExamRescuePlan(planId);
    const updated = plans.filter(p => p.id !== planId);
    setPlans(updated);
    if (selectedPlanId === planId) {
      setSelectedPlanId(updated[0]?.id || null);
    }
  };

  const handleCreatePlan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUser) return;

    const topics = formData.topicsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const weakTopics = formData.weakTopicsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const examDateObj = new Date(formData.examDate);
    const daysUntilExam = Math.max(1, Math.ceil((examDateObj.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));

    // Transparent spaced-repetition algorithm
    const generatedTasks: ExamRescueTask[] = [];
    let taskCounter = 1;

    // Phase 1: High priority weak topic review
    weakTopics.forEach((topic, idx) => {
      const dayOffset = Math.min(daysUntilExam - 1, Math.floor(idx / 2));
      const targetDate = new Date(Date.now() + dayOffset * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      generatedTasks.push({
        id: `task_${Date.now()}_${taskCounter++}`,
        title: `Review ${topic}`,
        topic,
        priority: 'high',
        scheduledDate: targetDate,
        dueDate: targetDate,
        estimatedMinutes: Math.min(formData.dailyMinutes, 45),
        isCompleted: false,
        completed: false,
        type: 'concept_review',
        recommendedTutorSubject: formData.subject
      });

      generatedTasks.push({
        id: `task_${Date.now()}_${taskCounter++}`,
        title: `${topic} Practice Drill`,
        topic: `${topic} - Practice Drill`,
        priority: 'high',
        scheduledDate: targetDate,
        dueDate: targetDate,
        estimatedMinutes: 30,
        isCompleted: false,
        completed: false,
        type: 'practice_problems'
      });
    });

    // Phase 2: Other regular topics
    topics.filter(t => !weakTopics.includes(t)).forEach((topic, idx) => {
      const dayOffset = Math.min(daysUntilExam - 1, 1 + Math.floor(idx / 2));
      const targetDate = new Date(Date.now() + dayOffset * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      generatedTasks.push({
        id: `task_${Date.now()}_${taskCounter++}`,
        title: `Study ${topic}`,
        topic,
        priority: 'medium',
        scheduledDate: targetDate,
        dueDate: targetDate,
        estimatedMinutes: 30,
        isCompleted: false,
        completed: false,
        type: 'concept_review'
      });
    });

    // Phase 3: Final diagnostic quiz 1 day before exam
    const finalDate = new Date(examDateObj.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const quizDate = finalDate > new Date().toISOString().split('T')[0] ? finalDate : new Date().toISOString().split('T')[0];
    generatedTasks.push({
      id: `task_${Date.now()}_${taskCounter++}`,
      title: `${formData.subject} Comprehensive Mock Diagnostic Quiz`,
      topic: `${formData.subject} Comprehensive Mock Diagnostic Quiz`,
      priority: 'high',
      scheduledDate: quizDate,
      dueDate: quizDate,
      estimatedMinutes: 25,
      isCompleted: false,
      completed: false,
      type: 'quiz'
    });

    const newPlan: ExamRescuePlan = {
      id: `plan_${Date.now()}`,
      userId: activeUser.id,
      subject: formData.subject,
      examDate: formData.examDate,
      topics: topics,
      topicsToStudy: topics,
      weakTopics: weakTopics,
      confidenceLevel: formData.confidence,
      selfRatedConfidence: formData.confidence,
      dailyStudyHours: Math.round((formData.dailyMinutes / 60) * 10) / 10,
      dailyStudyMinutes: formData.dailyMinutes,
      tasks: generatedTasks,
      recommendedTutorSubjects: [formData.subject],
      overallProgressPercent: 0,
      createdAt: new Date().toISOString()
    };

    storage.saveExamRescuePlan(newPlan);
    setPlans(prev => [newPlan, ...prev]);
    setSelectedPlanId(newPlan.id);
    setShowCreateModal(false);
    setToastMessage(`Exam Rescue Plan created for ${newPlan.subject}!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Find relevant tutors for the active subject
  const relevantTutors = activePlan 
    ? tutors.filter(t => 
        t.profile.verified && 
        t.profile.subjects.some(s => 
          s.subject.toLowerCase().includes(activePlan.subject.toLowerCase()) || 
          activePlan.subject.toLowerCase().includes(s.subject.toLowerCase())
        )
      ).slice(0, 3)
    : [];

  const completedCount = activePlan ? activePlan.tasks.filter((t: ExamRescueTask) => t.isCompleted || t.completed).length : 0;
  const progressPercent = activePlan && activePlan.tasks.length > 0 
    ? Math.round((completedCount / activePlan.tasks.length) * 100) 
    : 0;

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 bg-emerald-600 text-white font-medium rounded-xl shadow-xl shadow-emerald-500/20 animate-bounce">
          <Sparkles className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-red-950/60 via-indigo-950/80 to-slate-900 border border-red-500/30 p-6 md:p-8 backdrop-blur-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-red-500/20 text-red-400 border border-red-500/30 mb-3">
              <Flame className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              Emergency Exam Rescue Engine
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
              Exam Rescue Mode
            </h1>
            <p className="mt-1 text-slate-300 text-sm md:text-base max-w-2xl">
              Spaced-repetition revision sprint tailored to your exact exam date and weak topics. 
              Priority tasks, mentor bookings, and revision checkpoints scheduled automatically.
            </p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-red-600 to-indigo-600 hover:from-red-500 hover:to-indigo-500 text-white font-semibold shadow-lg shadow-red-500/25 transition-all cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            New Rescue Sprint
          </button>
        </div>
      </div>

      {/* Plan Selector Bar */}
      {plans.length > 0 && (
        <div className="flex items-center gap-3 overflow-x-auto pb-2">
          {plans.map(plan => {
            const countdown = getCountdown(plan.examDate);
            const isSelected = plan.id === activePlan?.id;
            return (
              <button
                key={plan.id}
                onClick={() => setSelectedPlanId(plan.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-medium transition-all whitespace-nowrap ${
                  isSelected
                    ? 'bg-indigo-600/20 border-indigo-500/50 text-white shadow-md shadow-indigo-500/10'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span className="font-semibold text-slate-200">{plan.subject}</span>
                <span className="text-xs px-2 py-0.5 rounded-md bg-slate-800 text-slate-400">
                  {countdown.isPast ? 'Exam Concluded' : `${countdown.days}d ${countdown.hours}h left`}
                </span>
                {plan.isDemoSample && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    SAMPLE
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Main Plan View */}
      {activePlan ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Countdown & Checklist */}
          <div className="lg:col-span-2 space-y-6">
            {/* Countdown & Metrics Card */}
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-6 backdrop-blur-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-white">{activePlan.subject}</h2>
                    {activePlan.isDemoSample && (
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        SAMPLE DATA
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      Exam Date: {new Date(activePlan.examDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-indigo-400" />
                      {activePlan.dailyStudyMinutes || 90} mins/day allocated
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRescheduleMissed}
                    title="Reschedule overdue tasks to today"
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700 transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
                    Reschedule Overdue
                  </button>
                  <button
                    onClick={() => handleDeletePlan(activePlan.id)}
                    title="Delete sprint"
                    className="p-2 rounded-lg bg-slate-800/50 hover:bg-red-500/20 text-slate-400 hover:text-red-400 border border-slate-700 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Progress and Countdown Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-800">
                  <div className="text-xs text-slate-400 mb-1">Time Remaining</div>
                  {(() => {
                    const cd = getCountdown(activePlan.examDate);
                    return cd.isPast ? (
                      <div className="text-lg font-bold text-slate-400">Concluded</div>
                    ) : (
                      <div className="text-xl font-bold text-red-400 flex items-baseline gap-1">
                        {cd.days}<span className="text-xs text-slate-400 font-normal">d</span> {cd.hours}<span className="text-xs text-slate-400 font-normal">h</span>
                      </div>
                    );
                  })()}
                </div>

                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-800">
                  <div className="text-xs text-slate-400 mb-1">Sprint Progress</div>
                  <div className="text-xl font-bold text-indigo-400">{progressPercent}%</div>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-800">
                  <div className="text-xs text-slate-400 mb-1">Completed Tasks</div>
                  <div className="text-xl font-bold text-emerald-400">
                    {completedCount} / {activePlan.tasks.length}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-800">
                  <div className="text-xs text-slate-400 mb-1">Confidence Rating</div>
                  <div className="text-xl font-bold text-amber-400">
                    {activePlan.selfRatedConfidence || activePlan.confidenceLevel || 3} / 5
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-6">
                <div className="flex justify-between text-xs text-slate-400 mb-2">
                  <span>Sprint Completion Rate</span>
                  <span>{progressPercent}%</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-red-500 via-indigo-500 to-emerald-500 transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Daily Revision Checklist */}
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-6 backdrop-blur-xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                  Personalized Revision Checklist
                </h3>
                <span className="text-xs text-slate-400">
                  Prioritized by knowledge gaps & exam deadline
                </span>
              </div>

              <div className="space-y-3">
                {activePlan.tasks.map((task: ExamRescueTask) => {
                  const taskDueDate = task.dueDate || task.scheduledDate;
                  const isTaskDone = task.isCompleted || task.completed;
                  const isOverdue = !isTaskDone && new Date(taskDueDate) < new Date(new Date().toISOString().split('T')[0]);

                  return (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task.id)}
                      className={`group flex items-start justify-between gap-4 p-4 rounded-xl border transition-all cursor-pointer ${
                        isTaskDone 
                          ? 'bg-slate-900/40 border-slate-800/60 opacity-60' 
                          : isOverdue
                          ? 'bg-red-950/20 border-red-500/40 hover:border-red-500'
                          : 'bg-slate-800/40 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/70'
                      }`}
                    >
                      <div className="flex items-start gap-3.5">
                        <button
                          type="button"
                          className="mt-0.5 text-indigo-400 focus:outline-none"
                        >
                          {isTaskDone ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                          ) : (
                            <Circle className="w-5 h-5 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                          )}
                        </button>

                        <div>
                          <div className={`font-medium text-sm ${isTaskDone ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                            {task.topic}
                          </div>
                          <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-400">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-slate-500" />
                              Due: {taskDueDate}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-slate-500" />
                              {task.estimatedMinutes} mins
                            </span>
                            {isOverdue && (
                              <span className="text-red-400 font-semibold flex items-center gap-0.5">
                                <AlertTriangle className="w-3 h-3" /> Overdue
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          task.priority === 'high' 
                            ? 'bg-red-500/20 text-red-300 border border-red-500/30' 
                            : task.priority === 'medium'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                        }`}>
                          {task.priority}
                        </span>
                        <span className="text-xs text-indigo-400/80 font-mono bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                          +15 XP
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Col: Weak Topics, Diagnostic shortcut & Recommended Tutors */}
          <div className="space-y-6">
            {/* Weak Topics Analysis */}
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-6 backdrop-blur-xl">
              <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Target Weak Topics
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                These topics receive 2x scheduling priority in your study sequence:
              </p>
              <div className="flex flex-wrap gap-2">
                {activePlan.weakTopics.map((wt: string, idx: number) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-red-500/10 text-red-300 border border-red-500/25"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                    {wt}
                  </span>
                ))}
              </div>

              {/* Diagnostic shortcut */}
              <div className="mt-6 pt-5 border-t border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-300">Diagnostic Readiness</span>
                  <span className="text-[10px] text-indigo-400">Knowledge Check</span>
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  Validate your retention by taking a diagnostic quiz on {activePlan.subject}.
                </p>
                <button
                  onClick={() => onNavigateToKnowledgeCheck && onNavigateToKnowledgeCheck(activePlan.subject)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 text-xs font-semibold transition-colors cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  Launch Diagnostic Quiz
                </button>
              </div>
            </div>

            {/* Recommended Tutors for this Exam */}
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-6 backdrop-blur-xl">
              <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-emerald-400" />
                Approved Mentors for {activePlan.subject}
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Book a 1-on-1 sprint review with peer tutors who have mastered this syllabus:
              </p>

              {relevantTutors.length > 0 ? (
                <div className="space-y-3">
                  {relevantTutors.map(item => (
                    <div 
                      key={item.user.id}
                      className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center justify-between gap-3 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs shrink-0">
                          {item.user.name.split(' ').map((n: string) => n[0]).join('')}
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-white">{item.user.name}</div>
                          <div className="text-[11px] text-slate-400">
                            ⭐ {item.profile.rating} ({item.profile.reviewCount} reviews)
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => onNavigateToTutors && onNavigateToTutors(activePlan.subject)}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow transition-colors shrink-0 cursor-pointer"
                      >
                        Book
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-xs text-slate-500">
                  No registered mentors found for this specific subject right now.
                </div>
              )}
            </div>

            {/* Pro Tip Box */}
            <div className="rounded-2xl bg-indigo-950/30 border border-indigo-500/20 p-5">
              <div className="flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-1">
                  <div className="font-semibold text-indigo-200">Spaced-Repetition Tip</div>
                  <p className="text-slate-400">
                    Review your high-priority weak topics at least 48 hours and 12 hours before sitting for the exam. Complete the diagnostic mock 1 day before.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-12 text-center max-w-xl mx-auto backdrop-blur-xl">
          <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4 text-red-400">
            <Flame className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">No Active Exam Rescue Plans</h3>
          <p className="text-sm text-slate-400 mb-6">
            Facing an upcoming exam, mid-term, or viva? Create an Exam Rescue Plan to schedule spaced-repetition revision and match with top peer tutors.
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-indigo-600 text-white font-semibold shadow-lg shadow-indigo-500/25 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Create Your First Exam Rescue Sprint
          </button>
        </div>
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 md:p-8 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
              <Flame className="w-5 h-5 text-red-400" />
              New Exam Rescue Sprint
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Enter your exam details. Our algorithm generates a day-by-day revision schedule prioritized by your weak topics.
            </p>

            <form onSubmit={handleCreatePlan} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Subject / Course Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={e => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="e.g. Database Management Systems, Data Structures"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Exam Date
                </label>
                <input
                  type="date"
                  required
                  min={new Date().toISOString().split('T')[0]}
                  value={formData.examDate}
                  onChange={e => setFormData({ ...formData, examDate: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Topics to Study (Comma-separated)
                </label>
                <textarea
                  rows={2}
                  value={formData.topicsInput}
                  onChange={e => setFormData({ ...formData, topicsInput: e.target.value })}
                  placeholder="e.g. Relational Algebra, Normalization, SQL Joins, Indexing"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-red-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Struggling / Weak Topics (Comma-separated)
                </label>
                <textarea
                  rows={2}
                  value={formData.weakTopicsInput}
                  onChange={e => setFormData({ ...formData, weakTopicsInput: e.target.value })}
                  placeholder="e.g. BCNF Decomposition, B+ Tree Indexing"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-red-500/30 text-white text-sm focus:border-red-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Current Confidence (1-5)
                  </label>
                  <select
                    value={formData.confidence}
                    onChange={e => setFormData({ ...formData, confidence: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  >
                    <option value={1}>1 - Panic Mode (Beginner)</option>
                    <option value={2}>2 - Struggling (Some doubts)</option>
                    <option value={3}>3 - Moderate (Fair grasp)</option>
                    <option value={4}>4 - Confident (Needs polish)</option>
                    <option value={5}>5 - Mastery (Ready to ace)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Daily Study Time
                  </label>
                  <select
                    value={formData.dailyMinutes}
                    onChange={e => setFormData({ ...formData, dailyMinutes: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-indigo-500 focus:outline-none"
                  >
                    <option value={45}>45 mins / day</option>
                    <option value={60}>60 mins / day</option>
                    <option value={90}>90 mins / day</option>
                    <option value={120}>120 mins / day</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-indigo-600 text-white text-sm font-semibold shadow-lg shadow-indigo-500/25 transition-all cursor-pointer"
                >
                  Generate Plan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
